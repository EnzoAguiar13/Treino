import Dexie, { Table } from 'dexie';

export interface Exercicio {
  id?: number;
  nome: string;
  grupo_muscular: string;
  criado_por_usuario: boolean;
}

export interface Serie {
  id?: number;
  exercicio_id: number;
  data: string;
  peso_kg: number;
  repeticoes: number;
  muscle_round: boolean;
  concluida: boolean;
  observacao: string;
  ordem: number;
  treino_dia: string;
}

export interface SessaoMusculacao {
  id?: number;
  data: string;
  dia_semana: string;
  exercicios_realizados: string;
  duracao_minutos: number;
}

export interface SessaoCardio {
  id?: number;
  data: string;
  tipo_cardio: string;
  duracao_segundos: number;
  calorias_totais: number;
  fc_media: number;
  calorias_por_minuto: number;
}

export interface Refeicao {
  id?: number;
  data: string;
  horario: string;
  nome_refeicao: string;
  alimentos: string;
  totais: string;
}

export interface Usuario {
  id?: number;
  peso: number;
  altura: number;
  idade: number;
  sexo: string;
  nivel_atividade: string;
  objetivo: string;
  foto_perfil_base64: string;
  timer_descanso_padrao: number;
  incremento_peso_padrao: number;
}

export interface TreinoDia {
  id?: number;
  dia_semana: string;
  exercicio_id: number;
  ordem: number;
}

class FitnessDB extends Dexie {
  exercicios!: Table<Exercicio>;
  series!: Table<Serie>;
  sessoes_musculacao!: Table<SessaoMusculacao>;
  sessoes_cardio!: Table<SessaoCardio>;
  refeicoes!: Table<Refeicao>;
  usuario!: Table<Usuario>;
  treino_dias!: Table<TreinoDia>;

  constructor() {
    super('EnzoFitnessDB');
    this.version(1).stores({
      exercicios: '++id, nome, grupo_muscular, criado_por_usuario',
      series: '++id, exercicio_id, data, treino_dia',
      sessoes_musculacao: '++id, data, dia_semana',
      sessoes_cardio: '++id, data, tipo_cardio',
      refeicoes: '++id, data, horario',
      usuario: '++id',
      treino_dias: '++id, dia_semana, exercicio_id, ordem',
    });
  }
}

export const db = new FitnessDB();

const PLANILHA_TREINO: { dia: string; exercicios: { nome: string; grupo: string }[] }[] = [
  {
    dia: 'Segunda',
    exercicios: [
      { nome: 'Remada Pronada', grupo: 'Costas' },
      { nome: 'Puxada Aberta', grupo: 'Costas' },
      { nome: 'Pulldown', grupo: 'Costas' },
      { nome: 'Remada Neutra', grupo: 'Costas' },
      { nome: 'Elevação Y', grupo: 'Posterior de Ombro' },
      { nome: 'Bayxan', grupo: 'Bíceps' },
      { nome: 'Scott', grupo: 'Bíceps' },
    ],
  },
  {
    dia: 'Terça',
    exercicios: [
      { nome: 'Supino Inclinado', grupo: 'Peito' },
      { nome: 'Voador', grupo: 'Peito' },
      { nome: 'Paralela', grupo: 'Peito' },
      { nome: 'Elevação Lateral', grupo: 'Ombro' },
      { nome: 'Polia Frontal', grupo: 'Ombro' },
      { nome: 'Tríceps Unilateral', grupo: 'Tríceps' },
      { nome: 'Tríceps Francês Conjugado', grupo: 'Tríceps' },
    ],
  },
  {
    dia: 'Quarta',
    exercicios: [
      { nome: 'Agachamento', grupo: 'Pernas' },
      { nome: 'Leg 45 Unilateral', grupo: 'Pernas' },
      { nome: 'Cadeira Flexora', grupo: 'Pernas' },
      { nome: 'Cadeira Extensora', grupo: 'Pernas' },
      { nome: 'Panturrilha', grupo: 'Pernas' },
      { nome: 'Martelo na Polia', grupo: 'Bíceps' },
      { nome: 'Abdômen - crunch na polia', grupo: 'Abdômen' },
    ],
  },
  {
    dia: 'Sexta',
    exercicios: [
      { nome: 'Remada Pronada', grupo: 'Costas' },
      { nome: 'Puxada Pronada', grupo: 'Costas' },
      { nome: 'Serrote', grupo: 'Costas' },
      { nome: 'Puxada Unilateral', grupo: 'Costas' },
      { nome: 'Polia Conjugada', grupo: 'Posterior de Ombro' },
      { nome: 'Bayxan', grupo: 'Bíceps' },
      { nome: 'Scott', grupo: 'Bíceps' },
    ],
  },
  {
    dia: 'Sábado',
    exercicios: [
      { nome: 'Supino Inclinado', grupo: 'Peito' },
      { nome: 'Voador', grupo: 'Peito' },
      { nome: 'Desenvolvimento', grupo: 'Ombro' },
      { nome: 'Elevação Lateral na Polia', grupo: 'Ombro' },
      { nome: 'Elevação Frontal na Polia', grupo: 'Ombro' },
      { nome: 'Tríceps Francês', grupo: 'Tríceps' },
      { nome: 'Tríceps Testa', grupo: 'Tríceps' },
    ],
  },
];

export async function initializeDB() {
  const count = await db.exercicios.count();
  if (count === 0) {
    const exercicioMap: Record<string, number> = {};

    for (const dia of PLANILHA_TREINO) {
      for (const ex of dia.exercicios) {
        const key = `${ex.nome}-${ex.grupo}`;
        if (!exercicioMap[key]) {
          const id = await db.exercicios.add({
            nome: ex.nome,
            grupo_muscular: ex.grupo,
            criado_por_usuario: false,
          });
          exercicioMap[key] = id as number;
        }
      }
    }

    for (const dia of PLANILHA_TREINO) {
      for (let i = 0; i < dia.exercicios.length; i++) {
        const ex = dia.exercicios[i];
        const key = `${ex.nome}-${ex.grupo}`;
        await db.treino_dias.add({
          dia_semana: dia.dia,
          exercicio_id: exercicioMap[key],
          ordem: i,
        });
      }
    }
  }

  const usuarioCount = await db.usuario.count();
  if (usuarioCount === 0) {
    await db.usuario.add({
      peso: 80,
      altura: 175,
      idade: 20,
      sexo: 'masculino',
      nivel_atividade: 'Moderadamente ativo',
      objetivo: 'Ganhar massa muscular',
      foto_perfil_base64: '',
      timer_descanso_padrao: 90,
      incremento_peso_padrao: 2.5,
    });
  }
}

export async function getExerciciosDoDia(dia: string): Promise<{ treino: TreinoDia; exercicio: Exercicio }[]> {
  const treinoDias = await db.treino_dias.where('dia_semana').equals(dia).sortBy('ordem');
  const result = [];
  for (const td of treinoDias) {
    const ex = await db.exercicios.get(td.exercicio_id);
    if (ex) result.push({ treino: td, exercicio: ex });
  }
  return result;
}

export async function getUltimaSerie(exercicioId: number, dia: string): Promise<Serie | undefined> {
  const series = await db.series
    .where('exercicio_id').equals(exercicioId)
    .filter(s => s.treino_dia === dia)
    .sortBy('data');
  
  if (series.length === 0) return undefined;
  
  const lastDate = series[series.length - 1].data;
  const seriesLastDate = series.filter(s => s.data === lastDate);
  return seriesLastDate[0];
}

export async function getSeriesDoDia(exercicioId: number, dia: string, data: string): Promise<Serie[]> {
  return db.series
    .where('exercicio_id').equals(exercicioId)
    .filter(s => s.treino_dia === dia && s.data === data)
    .sortBy('ordem');
}

export async function getHistoricoExercicio(exercicioId: number) {
  const series = await db.series
    .where('exercicio_id').equals(exercicioId)
    .sortBy('data');
  
  const byDate: Record<string, Serie[]> = {};
  for (const s of series) {
    if (!byDate[s.data]) byDate[s.data] = [];
    byDate[s.data].push(s);
  }
  
  return Object.entries(byDate).map(([data, seriesDia]) => ({
    data,
    maxPeso: Math.max(...seriesDia.map(s => s.peso_kg)),
    series: seriesDia,
  }));
}

export async function getAllExercicios(): Promise<Exercicio[]> {
  return db.exercicios.toArray();
}
