import { useRef, useEffect, useState, useCallback } from 'react';
import * as THREE from 'three';
import { motion, AnimatePresence } from 'framer-motion';

interface Module {
  id: string;
  label: string;
  color: string;
  x: number;
  y: number;
  icon: string;
}

const MODULES: Module[] = [
  { id: 'treino', label: 'TREINO', color: '#00BFFF', x: -3.5, y: 2, icon: '💪' },
  { id: 'cardio', label: 'CARDIO', color: '#00E5FF', x: 3.5, y: 2, icon: '🏃' },
  { id: 'nutricao', label: 'NUTRIÇÃO', color: '#00FFD1', x: 4, y: -0.5, icon: '🥗' },
  { id: 'historico', label: 'HISTÓRICO', color: '#0080FF', x: -3.5, y: -2, icon: '📊' },
  { id: 'perfil', label: 'PERFIL', color: '#7B8FFF', x: 0, y: -4, icon: '👤' },
];

const NAV_ITEMS = [
  { id: 'treino', label: 'TREINO', icon: '💪' },
  { id: 'cardio', label: 'CARDIO', icon: '🏃' },
  { id: 'nutricao', label: 'NUTRIÇÃO', icon: '🥗' },
  { id: 'historico', label: 'HISTÓRICO', icon: '📊' },
  { id: 'perfil', label: 'PERFIL', icon: '👤' },
];

interface Universe3DProps {
  onModuleSelect: (moduleId: string) => void;
}

export default function Universe3D({ onModuleSelect }: Universe3DProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const earthRef = useRef<THREE.Mesh | null>(null);
  const cloudsRef = useRef<THREE.Mesh | null>(null);
  const atmosphereRef = useRef<THREE.Mesh | null>(null);
  const frameRef = useRef<number>(0);
  const isDraggingRef = useRef(false);
  const lastTouchRef = useRef({ x: 0, y: 0 });
  const autoRotateRef = useRef(true);
  const earthRotYRef = useRef(0);
  const earthRotXRef = useRef(0.15);
  const cloudsRotYRef = useRef(0);
  const moduleMeshesRef = useRef<THREE.Mesh[]>([]);
  const [modulePositions, setModulePositions] = useState<{ id: string; screenX: number; screenY: number; visible: boolean }[]>([]);
  const [hoveredModule, setHoveredModule] = useState<string | null>(null);
  const [transitioning, setTransitioning] = useState(false);
  const [selectedModule, setSelectedModule] = useState<string | null>(null);

  const projectToScreen = useCallback((x: number, y: number, z: number) => {
    if (!cameraRef.current || !rendererRef.current) return { screenX: 0, screenY: 0, visible: true };
    const vector = new THREE.Vector3(x, y, z);
    vector.project(cameraRef.current);
    const canvas = rendererRef.current.domElement;
    const screenX = (vector.x * 0.5 + 0.5) * canvas.clientWidth;
    const screenY = (-vector.y * 0.5 + 0.5) * canvas.clientHeight;
    const visible = vector.z < 1;
    return { screenX, screenY, visible };
  }, []);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const W = mount.clientWidth;
    const H = mount.clientHeight;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0a);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(50, W / H, 0.1, 500);
    camera.position.z = 7;
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = false;
    rendererRef.current = renderer;
    mount.appendChild(renderer.domElement);

    // Stars field - 8000 points
    const starsGeo = new THREE.BufferGeometry();
    const starsCount = 8000;
    const starPos = new Float32Array(starsCount * 3);
    for (let i = 0; i < starsCount * 3; i++) {
      starPos[i] = (Math.random() - 0.5) * 200;
    }
    starsGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    const starsMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.1, sizeAttenuation: true });
    scene.add(new THREE.Points(starsGeo, starsMat));

    // Texture loader
    const tl = new THREE.TextureLoader();

    // Earth sphere
    const earthGeo = new THREE.SphereGeometry(2, 64, 64);
    const earthMat = new THREE.MeshPhongMaterial({
      map: tl.load('https://unpkg.com/three-globe/example/img/earth-blue-marble.jpg'),
      bumpMap: tl.load('https://unpkg.com/three-globe/example/img/earth-topology.png'),
      bumpScale: 0.05,
      specularMap: tl.load('https://unpkg.com/three-globe/example/img/earth-water.png'),
      specular: new THREE.Color(0x00bfff),
      shininess: 15,
    });
    const earth = new THREE.Mesh(earthGeo, earthMat);
    earth.rotation.x = 0.15;
    scene.add(earth);
    earthRef.current = earth;

    // Clouds
    const cloudsGeo = new THREE.SphereGeometry(2.02, 64, 64);
    const cloudsMat = new THREE.MeshPhongMaterial({
      map: tl.load('https://unpkg.com/three-globe/example/img/earth-clouds.png'),
      transparent: true,
      opacity: 0.4,
    });
    const clouds = new THREE.Mesh(cloudsGeo, cloudsMat);
    clouds.rotation.x = 0.15;
    scene.add(clouds);
    cloudsRef.current = clouds;

    // Atmosphere glow
    const atmGeo = new THREE.SphereGeometry(2.15, 64, 64);
    const atmMat = new THREE.MeshPhongMaterial({
      color: 0x00bfff,
      transparent: true,
      opacity: 0.08,
      side: THREE.BackSide,
    });
    const atmosphere = new THREE.Mesh(atmGeo, atmMat);
    scene.add(atmosphere);
    atmosphereRef.current = atmosphere;

    // Outer glow ring
    const glowGeo = new THREE.SphereGeometry(2.25, 64, 64);
    const glowMat = new THREE.MeshBasicMaterial({
      color: 0x00bfff,
      transparent: true,
      opacity: 0.03,
      side: THREE.BackSide,
    });
    scene.add(new THREE.Mesh(glowGeo, glowMat));

    // Lighting: Sun + ambient
    const sun = new THREE.DirectionalLight(0xffffff, 1.2);
    sun.position.set(5, 3, 5);
    scene.add(sun);
    scene.add(new THREE.AmbientLight(0x0a0a2e, 0.3));

    // Module orbital spheres
    const meshes: THREE.Mesh[] = [];
    MODULES.forEach(mod => {
      const geo = new THREE.SphereGeometry(0.2, 32, 32);
      const mat = new THREE.MeshPhongMaterial({
        color: new THREE.Color(mod.color),
        emissive: new THREE.Color(mod.color),
        emissiveIntensity: 0.6,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(mod.x, mod.y, 0.2);
      mesh.userData = { moduleId: mod.id };
      scene.add(mesh);
      meshes.push(mesh);

      // Point light for each module
      const light = new THREE.PointLight(new THREE.Color(mod.color), 0.5, 3);
      light.position.set(mod.x, mod.y, 0.5);
      scene.add(light);
    });
    moduleMeshesRef.current = meshes;

    // Orbit lines (decorative circles)
    for (let i = 0; i < 3; i++) {
      const orbitGeo = new THREE.RingGeometry(3.8 + i * 0.3, 3.82 + i * 0.3, 128);
      const orbitMat = new THREE.MeshBasicMaterial({
        color: 0x00bfff,
        transparent: true,
        opacity: 0.03 - i * 0.005,
        side: THREE.DoubleSide,
      });
      const orbit = new THREE.Mesh(orbitGeo, orbitMat);
      orbit.rotation.x = Math.PI / 2;
      scene.add(orbit);
    }

    // Animation loop
    let time = 0;
    const animate = () => {
      frameRef.current = requestAnimationFrame(animate);
      time += 0.016;

      // Auto-rotate
      if (autoRotateRef.current) {
        earthRotYRef.current += 0.0008;
      }

      if (earthRef.current) {
        earthRef.current.rotation.y = earthRotYRef.current;
        earthRef.current.rotation.x = earthRotXRef.current;
      }
      if (cloudsRef.current) {
        cloudsRotYRef.current += 0.001;
        cloudsRef.current.rotation.y = cloudsRotYRef.current;
        cloudsRef.current.rotation.x = earthRotXRef.current;
      }
      if (atmosphereRef.current) {
        atmosphereRef.current.rotation.y = earthRotYRef.current;
        atmosphereRef.current.rotation.x = earthRotXRef.current;
      }

      // Pulse modules
      meshes.forEach((mesh, i) => {
        const pulse = 1 + Math.sin(time * 2.5 + i * 1.3) * 0.08;
        mesh.scale.setScalar(pulse);
      });

      renderer.render(scene, camera);

      // Project module positions to screen
      const positions = MODULES.map(mod => {
        const p = projectToScreen(mod.x, mod.y, 0.2);
        return { id: mod.id, ...p };
      });
      setModulePositions(positions);
    };
    animate();

    // Touch & mouse handling
    const getXY = (e: TouchEvent | MouseEvent) => {
      if ('touches' in e && e.touches.length > 0) {
        return { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
      return { x: (e as MouseEvent).clientX, y: (e as MouseEvent).clientY };
    };

    let autoRotateTimeout: ReturnType<typeof setTimeout>;

    const onStart = (e: TouchEvent | MouseEvent) => {
      isDraggingRef.current = true;
      autoRotateRef.current = false;
      clearTimeout(autoRotateTimeout);
      lastTouchRef.current = getXY(e);
    };

    const onMove = (e: TouchEvent | MouseEvent) => {
      if (!isDraggingRef.current) return;
      const pos = getXY(e);
      const dx = pos.x - lastTouchRef.current.x;
      const dy = pos.y - lastTouchRef.current.y;
      earthRotYRef.current += dx * 0.004;
      earthRotXRef.current += dy * 0.004;
      earthRotXRef.current = Math.max(-1.2, Math.min(1.2, earthRotXRef.current));
      lastTouchRef.current = pos;
    };

    const onEnd = () => {
      isDraggingRef.current = false;
      autoRotateTimeout = setTimeout(() => { autoRotateRef.current = true; }, 2500);
    };

    renderer.domElement.addEventListener('touchstart', onStart, { passive: true });
    renderer.domElement.addEventListener('touchmove', onMove, { passive: true });
    renderer.domElement.addEventListener('touchend', onEnd);
    renderer.domElement.addEventListener('mousedown', onStart);
    renderer.domElement.addEventListener('mousemove', onMove);
    renderer.domElement.addEventListener('mouseup', onEnd);

    // Resize
    const onResize = () => {
      if (!mount) return;
      const w = mount.clientWidth;
      const h = mount.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(frameRef.current);
      clearTimeout(autoRotateTimeout);
      window.removeEventListener('resize', onResize);
      renderer.domElement.removeEventListener('touchstart', onStart);
      renderer.domElement.removeEventListener('touchmove', onMove);
      renderer.domElement.removeEventListener('touchend', onEnd);
      renderer.domElement.removeEventListener('mousedown', onStart);
      renderer.domElement.removeEventListener('mousemove', onMove);
      renderer.domElement.removeEventListener('mouseup', onEnd);
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, [projectToScreen]);

  const handleModuleClick = useCallback((moduleId: string) => {
    if (transitioning) return;
    setSelectedModule(moduleId);
    setTransitioning(true);
    setTimeout(() => {
      onModuleSelect(moduleId);
      setTransitioning(false);
      setSelectedModule(null);
    }, 500);
  }, [transitioning, onModuleSelect]);

  return (
    <div className="fixed inset-0" style={{ background: '#0A0A0A' }}>
      {/* Three.js canvas mount */}
      <div ref={mountRef} className="absolute inset-0" />

      {/* Top bar */}
      <div
        className="absolute top-0 left-0 right-0 flex justify-between items-center px-5 z-20"
        style={{ paddingTop: 'calc(env(safe-area-inset-top) + 16px)', paddingBottom: '12px' }}
      >
        <div>
          <h1
            className="font-bebas text-3xl tracking-widest glow-blue leading-none"
            style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}
          >
            ENZO
          </h1>
          <p className="text-xs font-dm" style={{ color: '#333', letterSpacing: '0.2em' }}>FITNESS UNIVERSE</p>
        </div>
        <button
          onClick={() => handleModuleClick('perfil')}
          className="w-10 h-10 rounded-full flex items-center justify-center transition-all"
          style={{ background: 'rgba(20,20,20,0.9)', border: '1px solid #2A2A2A', backdropFilter: 'blur(10px)' }}
        >
          <span>👤</span>
        </button>
      </div>

      {/* Module floating labels */}
      {modulePositions.map(pos => {
        const mod = MODULES.find(m => m.id === pos.id)!;
        if (!pos.visible) return null;
        const isHovered = hoveredModule === pos.id;
        const isSelected = selectedModule === pos.id;

        return (
          <motion.div
            key={pos.id}
            className="absolute flex flex-col items-center cursor-pointer select-none"
            style={{
              left: pos.screenX,
              top: pos.screenY,
              transform: 'translate(-50%, -50%)',
              zIndex: 10,
            }}
            animate={{
              scale: isSelected ? 1.6 : isHovered ? 1.15 : 1,
            }}
            transition={{ duration: 0.25 }}
            onClick={() => handleModuleClick(pos.id)}
            onMouseEnter={() => setHoveredModule(pos.id)}
            onMouseLeave={() => setHoveredModule(null)}
          >
            <motion.div
              className="w-12 h-12 rounded-full flex items-center justify-center text-xl relative"
              style={{
                background: `radial-gradient(circle at center, ${mod.color}22, transparent)`,
                border: `1.5px solid ${mod.color}`,
                boxShadow: isHovered || isSelected
                  ? `0 0 30px ${mod.color}80, 0 0 60px ${mod.color}30`
                  : `0 0 15px ${mod.color}50`,
              }}
            >
              <span>{mod.icon}</span>
              {/* Outer ring */}
              <div
                className="absolute inset-0 rounded-full"
                style={{
                  border: `1px solid ${mod.color}33`,
                  transform: 'scale(1.4)',
                }}
              />
            </motion.div>
            <motion.span
              className="mt-1.5 font-dm font-bold tracking-widest whitespace-nowrap"
              style={{
                color: mod.color,
                textShadow: `0 0 15px ${mod.color}`,
                fontSize: '0.55rem',
                letterSpacing: '0.2em',
              }}
            >
              {mod.label}
            </motion.span>
          </motion.div>
        );
      })}

      {/* Bottom navigation */}
      <div
        className="absolute bottom-0 left-0 right-0 z-20"
        style={{
          background: 'rgba(0,0,0,0.75)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderTop: '1px solid rgba(255,255,255,0.05)',
          paddingBottom: 'calc(env(safe-area-inset-bottom) + 8px)',
        }}
      >
        <div className="flex justify-around items-center px-2 py-3">
          {NAV_ITEMS.map(item => (
            <button
              key={item.id}
              onClick={() => handleModuleClick(item.id)}
              className="flex flex-col items-center gap-1 px-3 py-1 rounded-xl transition-all"
              onMouseEnter={e => (e.currentTarget.style.background = 'rgba(0,191,255,0.08)')}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
            >
              <span className="text-lg">{item.icon}</span>
              <span className="font-dm" style={{ color: '#444', fontSize: '0.5rem', letterSpacing: '0.08em' }}>
                {item.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Portal transition overlay */}
      <AnimatePresence>
        {transitioning && (
          <motion.div
            className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            style={{ background: 'radial-gradient(circle at center, rgba(0,191,255,0.05) 0%, rgba(10,10,10,0.95) 70%)' }}
          >
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 3, opacity: 0 }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
              className="w-32 h-32 rounded-full"
              style={{ border: '2px solid #00BFFF', boxShadow: '0 0 40px #00BFFF' }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
