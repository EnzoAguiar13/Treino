import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { db, getAllExercicios, getHistoricoExercicio, Exercicio } from '../../db/database';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

type Aba = 'musculacao' | 'cardio';

export default function HistoricoModule({ onBack }: { onBack: () => void }) {
  const [aba, setAba] = useState<Aba>('musculacao');
  const [exercicios, setExercicios] = useState<Exercicio[]>([]);
  const [exercicioSelecionado, setExercicioSelecionado] = useState<Exercicio | null>(null);
  const [historico, setHistorico] = useState<{ data: string; maxPeso: number; series: any[] }[]>([]);
  const [historicoCardio, setHistoricoCardio] = useState<any[]>([]);
  const [busca, setBusca] = useState('');
  const [filtroCardio, setFiltroCardio] = useState<string>('Todos');

  useEffect(() => {
    getAllExercicios().then(setExercicios);
    db.sessoes_cardio.orderBy('data').reverse().toArray().then(setHistoricoCardio);
  }, []);

  const selecionarExercicio = async (ex: Exercicio) => {
    setExercicioSelecionado(ex);
    if (ex.id) {
      const hist = await getHistoricoExercicio(ex.id);
      setHistorico(hist);
    }
  };

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr);
    return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`;
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
  };

  const exerciciosFiltrados = exercicios.filter(ex =>
    ex.nome.toLowerCase().includes(busca.toLowerCase())
  );

  const cardioTipos = ['Todos', ...Array.from(new Set(historicoCardio.map(s => s.tipo_cardio)))];
  const cardioFiltrado = filtroCardio === 'Todos'
    ? historicoCardio
    : historicoCardio.filter(s => s.tipo_cardio === filtroCardio);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-4 px-4 pt-12 pb-4" style={{ borderBottom: '1px solid #1a1a1a' }}>
        <button onClick={exercicioSelecionado ? () => setExercicioSelecionado(null) : onBack} className="text-gray-400 p-2">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M5 12l7 7M5 12l7-7" /></svg>
        </button>
        <h1 className="font-bebas text-3xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>
          {exercicioSelecionado ? exercicioSelecionado.nome.toUpperCase() : 'HISTÓRICO'}
        </h1>
        {!exercicioSelecionado && (
          <div className="ml-auto flex gap-1">
            {(['musculacao', 'cardio'] as Aba[]).map(a => (
              <button
                key={a}
                onClick={() => setAba(a)}
                className="px-3 py-1.5 rounded-lg text-xs font-dm font-medium transition-all"
                style={{
                  background: aba === a ? 'rgba(0,191,255,0.15)' : 'transparent',
                  color: aba === a ? '#00BFFF' : '#555',
                  border: aba === a ? '1px solid rgba(0,191,255,0.3)' : '1px solid transparent',
                }}
              >
                {a === 'musculacao' ? '💪' : '🏃'}
              </button>
            ))}
          </div>
        )}
      </div>

      {aba === 'musculacao' && !exercicioSelecionado && (
        <div className="flex-1 overflow-y-auto px-4 py-3">
          <input
            type="text"
            placeholder="Buscar exercício..."
            value={busca}
            onChange={e => setBusca(e.target.value)}
            className="w-full px-4 py-3 rounded-xl text-white font-dm text-sm outline-none mb-4"
            style={{ background: '#141414', border: '1px solid #2A2A2A' }}
          />
          <div className="space-y-2">
            {exerciciosFiltrados.map((ex, idx) => (
              <motion.button
                key={ex.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.03 }}
                onClick={() => selecionarExercicio(ex)}
                className="w-full text-left p-4 rounded-xl flex items-center justify-between"
                style={{ background: '#141414', border: '1px solid #2A2A2A' }}
              >
                <div>
                  <p className="font-dm font-bold text-white text-sm">{ex.nome}</p>
                  <p className="text-xs font-dm" style={{ color: '#555' }}>{ex.grupo_muscular}</p>
                </div>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth="2"><path d="M9 18l6-6-6-6" /></svg>
              </motion.button>
            ))}
          </div>
        </div>
      )}

      {aba === 'musculacao' && exercicioSelecionado && (
        <div className="flex-1 overflow-y-auto px-4 py-3">
          {historico.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <span className="text-5xl mb-4">📈</span>
              <p className="font-dm text-gray-500">Sem registros para este exercício.</p>
            </div>
          ) : (
            <>
              {/* Graph */}
              <div className="card-dark p-4 rounded-xl mb-4">
                <p className="text-xs font-dm text-gray-500 mb-3">Evolução da carga máxima (kg)</p>
                <ResponsiveContainer width="100%" height={180}>
                  <LineChart data={historico.map(h => ({ data: formatDate(h.data), kg: h.maxPeso }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                    <XAxis dataKey="data" tick={{ fill: '#555', fontSize: 10 }} />
                    <YAxis tick={{ fill: '#555', fontSize: 10 }} unit="kg" />
                    <Tooltip
                      contentStyle={{ background: '#141414', border: '1px solid #2A2A2A', borderRadius: 8 }}
                      labelStyle={{ color: '#888' }}
                      itemStyle={{ color: '#00BFFF' }}
                    />
                    <Line
                      type="monotone"
                      dataKey="kg"
                      stroke="#00BFFF"
                      strokeWidth={2}
                      dot={{ fill: '#00BFFF', r: 4, strokeWidth: 0 }}
                      activeDot={{ r: 6, fill: '#00BFFF' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Sessions table */}
              <div className="space-y-3">
                {historico.slice().reverse().map((h, i) => (
                  <div key={i} className="card-dark p-4 rounded-xl">
                    <div className="flex justify-between items-center mb-2">
                      <p className="font-dm font-bold text-white text-sm">{h.data}</p>
                      <p className="font-bebas text-lg" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>
                        Max: {h.maxPeso}kg
                      </p>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {h.series.map((s: any, si: number) => (
                        <div key={si} className="text-center p-2 rounded-lg" style={{ background: '#0A0A0A' }}>
                          <p className="text-xs font-dm text-gray-500">S{si + 1}</p>
                          <p className="text-sm font-dm font-bold text-white">{s.peso_kg}kg</p>
                          <p className="text-xs font-dm text-gray-500">×{s.repeticoes}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {aba === 'cardio' && (
        <div className="flex-1 overflow-y-auto px-4 py-3">
          {/* Filter */}
          <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-3 mb-3">
            {cardioTipos.map(tipo => (
              <button
                key={tipo}
                onClick={() => setFiltroCardio(tipo)}
                className="px-3 py-1.5 rounded-lg text-xs font-dm font-medium transition-all shrink-0"
                style={{
                  background: filtroCardio === tipo ? 'rgba(0,191,255,0.15)' : '#141414',
                  color: filtroCardio === tipo ? '#00BFFF' : '#555',
                  border: `1px solid ${filtroCardio === tipo ? 'rgba(0,191,255,0.3)' : '#2A2A2A'}`,
                }}
              >
                {tipo}
              </button>
            ))}
          </div>

          {cardioFiltrado.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <span className="text-5xl mb-4">🏃</span>
              <p className="font-dm text-gray-500">Nenhuma sessão registrada.</p>
            </div>
          ) : (
            <>
              <div className="card-dark p-4 rounded-xl mb-4">
                <p className="text-xs font-dm text-gray-500 mb-3">Calorias por sessão</p>
                <ResponsiveContainer width="100%" height={150}>
                  <LineChart data={cardioFiltrado.slice(0, 10).reverse().map(s => ({ data: s.data.slice(5), cal: s.calorias_totais }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                    <XAxis dataKey="data" tick={{ fill: '#555', fontSize: 10 }} />
                    <YAxis tick={{ fill: '#555', fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: '#141414', border: '1px solid #2A2A2A', borderRadius: 8 }} />
                    <Line type="monotone" dataKey="cal" stroke="#00BFFF" strokeWidth={2} dot={{ fill: '#00BFFF', r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-2">
                {cardioFiltrado.map((s, i) => (
                  <div key={i} className="card-dark p-4 rounded-xl flex items-center justify-between">
                    <div>
                      <p className="font-dm font-bold text-white text-sm">{s.tipo_cardio}</p>
                      <p className="text-xs font-dm text-gray-500">{s.data} · {formatTime(s.duracao_segundos)} · ❤️ {s.fc_media}bpm</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bebas text-xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>{s.calorias_totais}</p>
                      <p className="text-xs font-dm text-gray-500">kcal</p>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
