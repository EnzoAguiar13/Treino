import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { db } from '../../db/database';

export default function PerfilModule({ onBack, onLogout }: { onBack: () => void; onLogout: () => void }) {
  const [peso, setPeso] = useState(80);
  const [altura, setAltura] = useState(175);
  const [idade, setIdade] = useState(20);
  const [timerDescanso, setTimerDescanso] = useState(90);
  const [incremento, setIncremento] = useState(2.5);
  const [foto, setFoto] = useState('');
  const [salvando, setSalvando] = useState(false);
  const [salvado, setSalvado] = useState(false);
  const [senhaAtual, setSenhaAtual] = useState('');
  const [novaSenha, setNovaSenha] = useState('');
  const [confirmSenha, setConfirmSenha] = useState('');
  const [senhaErro, setSenhaErro] = useState('');
  const [senhaSucesso, setSenhaSucesso] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    db.usuario.toArray().then(u => {
      if (u[0]) {
        setPeso(u[0].peso);
        setAltura(u[0].altura);
        setIdade(u[0].idade);
        setTimerDescanso(u[0].timer_descanso_padrao || 90);
        setIncremento(u[0].incremento_peso_padrao || 2.5);
        setFoto(u[0].foto_perfil_base64 || '');
      }
    });
  }, []);

  const salvar = async () => {
    setSalvando(true);
    const users = await db.usuario.toArray();
    if (users[0]?.id) {
      await db.usuario.update(users[0].id, {
        peso,
        altura,
        idade,
        timer_descanso_padrao: timerDescanso,
        incremento_peso_padrao: incremento,
        foto_perfil_base64: foto,
      });
    }
    setSalvando(false);
    setSalvado(true);
    setTimeout(() => setSalvado(false), 2000);
  };

  const handleFoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setFoto(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const alterarSenha = () => {
    setSenhaErro('');
    if (senhaAtual !== 'Pipoca1020*') { setSenhaErro('Senha atual incorreta.'); return; }
    if (novaSenha.length < 6) { setSenhaErro('Nova senha deve ter ao menos 6 caracteres.'); return; }
    if (novaSenha !== confirmSenha) { setSenhaErro('Confirmação não coincide.'); return; }
    setSenhaSucesso(true);
    setSenhaAtual(''); setNovaSenha(''); setConfirmSenha('');
    setTimeout(() => setSenhaSucesso(false), 3000);
  };

  const handleLogout = () => {
    localStorage.removeItem('enzo_session');
    onLogout();
  };

  const incrementoOptions = [1, 2.5, 5];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-4 px-4 pt-12 pb-4" style={{ borderBottom: '1px solid #1a1a1a' }}>
        <button onClick={onBack} className="text-gray-400 p-2">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M5 12l7 7M5 12l7-7" /></svg>
        </button>
        <h1 className="font-bebas text-3xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>PERFIL</h1>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 pb-10">
        {/* Avatar */}
        <div className="flex flex-col items-center mb-6">
          <div
            className="w-24 h-24 rounded-full flex items-center justify-center mb-3 cursor-pointer overflow-hidden"
            style={{ background: foto ? 'transparent' : '#141414', border: '2px solid #00BFFF', boxShadow: '0 0 20px rgba(0,191,255,0.3)' }}
            onClick={() => fileRef.current?.click()}
          >
            {foto ? (
              <img src={foto} alt="Foto" className="w-full h-full object-cover" />
            ) : (
              <span className="text-4xl">👤</span>
            )}
          </div>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFoto} />
          <p className="font-bebas text-2xl" style={{ color: '#fff', fontFamily: "'Bebas Neue', sans-serif" }}>ENZO</p>
          <p className="text-xs font-dm" style={{ color: '#555' }}>enzofortes13@gmail.com</p>
        </div>

        {/* Body stats */}
        <div className="card-dark p-4 rounded-xl mb-4">
          <p className="text-xs font-dm text-gray-500 mb-3 tracking-wider">DADOS CORPORAIS</p>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <p className="text-xs font-dm text-gray-600 mb-1">Peso (kg)</p>
              <input
                type="number"
                value={peso}
                onChange={e => setPeso(parseFloat(e.target.value))}
                className="w-full px-3 py-2 rounded-xl text-white font-dm text-sm outline-none text-center"
                style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
              />
            </div>
            <div>
              <p className="text-xs font-dm text-gray-600 mb-1">Altura (cm)</p>
              <input
                type="number"
                value={altura}
                onChange={e => setAltura(parseFloat(e.target.value))}
                className="w-full px-3 py-2 rounded-xl text-white font-dm text-sm outline-none text-center"
                style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
              />
            </div>
            <div>
              <p className="text-xs font-dm text-gray-600 mb-1">Idade</p>
              <input
                type="number"
                value={idade}
                onChange={e => setIdade(parseInt(e.target.value))}
                className="w-full px-3 py-2 rounded-xl text-white font-dm text-sm outline-none text-center"
                style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
              />
            </div>
          </div>
        </div>

        {/* Timer */}
        <div className="card-dark p-4 rounded-xl mb-4">
          <p className="text-xs font-dm text-gray-500 mb-3 tracking-wider">TIMER DE DESCANSO</p>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-dm text-gray-400">30s</span>
            <span className="font-bebas text-2xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>
              {timerDescanso}s
            </span>
            <span className="text-sm font-dm text-gray-400">300s</span>
          </div>
          <input
            type="range"
            min={30}
            max={300}
            step={15}
            value={timerDescanso}
            onChange={e => setTimerDescanso(parseInt(e.target.value))}
            className="w-full"
            style={{ accentColor: '#00BFFF' }}
          />
        </div>

        {/* Incremento */}
        <div className="card-dark p-4 rounded-xl mb-4">
          <p className="text-xs font-dm text-gray-500 mb-3 tracking-wider">INCREMENTO DE PESO</p>
          <div className="flex gap-2">
            {incrementoOptions.map(inc => (
              <button
                key={inc}
                onClick={() => setIncremento(inc)}
                className="flex-1 py-2 rounded-xl text-sm font-dm font-bold transition-all"
                style={{
                  background: incremento === inc ? 'rgba(0,191,255,0.15)' : '#0A0A0A',
                  border: `1px solid ${incremento === inc ? '#00BFFF' : '#2A2A2A'}`,
                  color: incremento === inc ? '#00BFFF' : '#555',
                }}
              >
                {inc}kg
              </button>
            ))}
          </div>
        </div>

        {/* Save button */}
        <motion.button
          onClick={salvar}
          disabled={salvando}
          whileTap={{ scale: 0.97 }}
          className="w-full py-4 rounded-xl font-bebas text-xl tracking-widest text-white gradient-blue mb-4"
          style={{ fontFamily: "'Bebas Neue', sans-serif" }}
        >
          {salvando ? 'SALVANDO...' : salvado ? '✓ SALVO!' : 'SALVAR ALTERAÇÕES'}
        </motion.button>

        {/* Change password */}
        <div className="card-dark p-4 rounded-xl mb-4">
          <p className="text-xs font-dm text-gray-500 mb-3 tracking-wider">ALTERAR SENHA</p>
          <div className="space-y-2">
            <input
              type="password"
              placeholder="Senha atual"
              value={senhaAtual}
              onChange={e => setSenhaAtual(e.target.value)}
              className="w-full px-3 py-2 rounded-xl text-white font-dm text-sm outline-none"
              style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
            />
            <input
              type="password"
              placeholder="Nova senha"
              value={novaSenha}
              onChange={e => setNovaSenha(e.target.value)}
              className="w-full px-3 py-2 rounded-xl text-white font-dm text-sm outline-none"
              style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
            />
            <input
              type="password"
              placeholder="Confirmar nova senha"
              value={confirmSenha}
              onChange={e => setConfirmSenha(e.target.value)}
              className="w-full px-3 py-2 rounded-xl text-white font-dm text-sm outline-none"
              style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
            />
            {senhaErro && <p className="text-xs font-dm" style={{ color: '#FF4444' }}>{senhaErro}</p>}
            {senhaSucesso && <p className="text-xs font-dm" style={{ color: '#00FFD1' }}>Senha alterada com sucesso!</p>}
            <button
              onClick={alterarSenha}
              className="w-full py-2 rounded-xl font-dm text-sm font-medium"
              style={{ background: '#1a1a1a', border: '1px solid #2A2A2A', color: '#888' }}
            >
              Alterar senha
            </button>
          </div>
        </div>

        {/* App version */}
        <p className="text-center text-xs font-dm text-gray-700 mb-4">Versão 1.0.0 • ENZO Fitness Universe</p>

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="w-full py-4 rounded-xl font-bebas text-xl tracking-widest mb-2"
          style={{ border: '1px solid #FF4444', color: '#FF4444', fontFamily: "'Bebas Neue', sans-serif", background: 'rgba(255,68,68,0.05)' }}
        >
          SAIR DA CONTA
        </button>
      </div>
    </div>
  );
}
