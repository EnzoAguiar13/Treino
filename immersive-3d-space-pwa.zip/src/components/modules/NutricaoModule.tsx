import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { db } from '../../db/database';

type Aba = 'adicionar' | 'diario' | 'dieta';

interface Alimento {
  nome: string;
  quantidade: number;
  calorias: number;
  proteinas: number;
  carboidratos: number;
  gorduras: number;
}

interface Totais {
  calorias: number;
  proteinas: number;
  carboidratos: number;
  gorduras: number;
}

const calcTotais = (alimentos: Alimento[]): Totais => ({
  calorias: alimentos.reduce((s, a) => s + a.calorias, 0),
  proteinas: alimentos.reduce((s, a) => s + a.proteinas, 0),
  carboidratos: alimentos.reduce((s, a) => s + a.carboidratos, 0),
  gorduras: alimentos.reduce((s, a) => s + a.gorduras, 0),
});

const NIVEIS = ['Sedentário', 'Levemente ativo', 'Moderadamente ativo', 'Muito ativo', 'Extremamente ativo'];
const FATORES: Record<string, number> = {
  'Sedentário': 1.2,
  'Levemente ativo': 1.375,
  'Moderadamente ativo': 1.55,
  'Muito ativo': 1.725,
  'Extremamente ativo': 1.9,
};
const OBJETIVOS = ['Ganhar massa muscular', 'Perder gordura', 'Manutenção'];

export default function NutricaoModule({ onBack }: { onBack: () => void }) {
  const [aba, setAba] = useState<Aba>('diario');
  const [nomeRefeicao, setNomeRefeicao] = useState('');
  const [alimentos, setAlimentos] = useState<Alimento[]>([{ nome: '', quantidade: 100, calorias: 0, proteinas: 0, carboidratos: 0, gorduras: 0 }]);
  const [refeicoesDia, setRefeicoesDia] = useState<any[]>([]);
  const [dataSelecionada, setDataSelecionada] = useState(new Date().toISOString().split('T')[0]);
  const [diasRecentes, setDiasRecentes] = useState<string[]>([]);

  // Dieta
  const [peso, setPeso] = useState(80);
  const [altura, setAltura] = useState(175);
  const [idade, setIdade] = useState(20);
  const [sexo, setSexo] = useState('masculino');
  const [nivel, setNivel] = useState('Moderadamente ativo');
  const [objetivo, setObjetivo] = useState('Ganhar massa muscular');
  const [resultado, setResultado] = useState<any>(null);
  const [metaCalorias, setMetaCalorias] = useState(2500);

  useEffect(() => {
    loadRefeicoes();
    loadUsuario();
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      days.push(d.toISOString().split('T')[0]);
    }
    setDiasRecentes(days);
  }, []);

  useEffect(() => {
    loadRefeicoes();
  }, [dataSelecionada]);

  const loadUsuario = async () => {
    const u = await db.usuario.toArray();
    if (u[0]) {
      setPeso(u[0].peso);
      setAltura(u[0].altura);
      setIdade(u[0].idade);
      setSexo(u[0].sexo);
      setNivel(u[0].nivel_atividade);
      setObjetivo(u[0].objetivo);
    }
  };

  const loadRefeicoes = async () => {
    const refeicoes = await db.refeicoes.where('data').equals(dataSelecionada).toArray();
    setRefeicoesDia(refeicoes);
  };

  const addAlimento = () => {
    setAlimentos(prev => [...prev, { nome: '', quantidade: 100, calorias: 0, proteinas: 0, carboidratos: 0, gorduras: 0 }]);
  };

  const updateAlimento = (idx: number, field: keyof Alimento, value: string | number) => {
    setAlimentos(prev => prev.map((a, i) => i === idx ? { ...a, [field]: value } : a));
  };

  const removeAlimento = (idx: number) => {
    setAlimentos(prev => prev.filter((_, i) => i !== idx));
  };

  const salvarRefeicao = async () => {
    if (!nomeRefeicao || alimentos.length === 0) return;
    const totais = calcTotais(alimentos);
    await db.refeicoes.add({
      data: dataSelecionada,
      horario: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      nome_refeicao: nomeRefeicao,
      alimentos: JSON.stringify(alimentos),
      totais: JSON.stringify(totais),
    });
    setNomeRefeicao('');
    setAlimentos([{ nome: '', quantidade: 100, calorias: 0, proteinas: 0, carboidratos: 0, gorduras: 0 }]);
    loadRefeicoes();
    setAba('diario');
  };

  const calcularDieta = () => {
    let tmb = sexo === 'masculino'
      ? (10 * peso) + (6.25 * altura) - (5 * idade) + 5
      : (10 * peso) + (6.25 * altura) - (5 * idade) - 161;
    let tdee = tmb * (FATORES[nivel] || 1.55);

    let caloriasAlvo = tdee;
    let proteinaG = 0;
    let gorduraG = 0;
    let carbG = 0;

    if (objetivo === 'Ganhar massa muscular') {
      caloriasAlvo = tdee + 300;
      proteinaG = peso * 2.2;
      gorduraG = (caloriasAlvo * 0.25) / 9;
      carbG = (caloriasAlvo - proteinaG * 4 - gorduraG * 9) / 4;
    } else if (objetivo === 'Perder gordura') {
      caloriasAlvo = tdee - 400;
      proteinaG = peso * 2.4;
      gorduraG = (caloriasAlvo * 0.25) / 9;
      carbG = (caloriasAlvo - proteinaG * 4 - gorduraG * 9) / 4;
    } else {
      caloriasAlvo = tdee;
      proteinaG = peso * 1.8;
      gorduraG = (caloriasAlvo * 0.25) / 9;
      carbG = (caloriasAlvo - proteinaG * 4 - gorduraG * 9) / 4;
    }

    const r = {
      calorias: Math.round(caloriasAlvo),
      proteina: Math.round(proteinaG),
      carbo: Math.round(carbG),
      gordura: Math.round(gorduraG),
    };
    setResultado(r);
    setMetaCalorias(r.calorias);
  };

  const totaisHoje = refeicoesDia.reduce((acc, ref) => {
    const t = JSON.parse(ref.totais || '{}');
    return {
      calorias: acc.calorias + (t.calorias || 0),
      proteinas: acc.proteinas + (t.proteinas || 0),
      carboidratos: acc.carboidratos + (t.carboidratos || 0),
      gorduras: acc.gorduras + (t.gorduras || 0),
    };
  }, { calorias: 0, proteinas: 0, carboidratos: 0, gorduras: 0 });

  const totaisAdicionando = calcTotais(alimentos);

  const formatData = (d: string) => {
    const parts = d.split('-');
    return `${parts[2]}/${parts[1]}`;
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-4 px-4 pt-12 pb-3" style={{ borderBottom: '1px solid #1a1a1a' }}>
        <button onClick={onBack} className="text-gray-400 p-2">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M5 12l7 7M5 12l7-7" /></svg>
        </button>
        <h1 className="font-bebas text-3xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>NUTRIÇÃO</h1>
        <div className="ml-auto flex gap-1">
          {(['diario', 'adicionar', 'dieta'] as Aba[]).map(a => (
            <button
              key={a}
              onClick={() => setAba(a)}
              className="px-2 py-1.5 rounded-lg text-xs font-dm font-medium transition-all"
              style={{
                background: aba === a ? 'rgba(0,191,255,0.15)' : 'transparent',
                color: aba === a ? '#00BFFF' : '#555',
                border: aba === a ? '1px solid rgba(0,191,255,0.3)' : '1px solid transparent',
                fontSize: '0.65rem',
              }}
            >
              {a === 'diario' ? '📅' : a === 'adicionar' ? '➕' : '🧮'}
            </button>
          ))}
        </div>
      </div>

      {aba === 'adicionar' && (
        <div className="flex-1 overflow-y-auto px-4 py-4">
          <input
            type="text"
            placeholder="Nome da refeição (ex: Almoço)"
            value={nomeRefeicao}
            onChange={e => setNomeRefeicao(e.target.value)}
            className="w-full px-4 py-3 rounded-xl text-white font-dm text-sm outline-none mb-4"
            style={{ background: '#141414', border: '1px solid #2A2A2A' }}
          />

          <p className="text-xs font-dm text-gray-500 mb-2">ALIMENTOS</p>

          {alimentos.map((al, idx) => (
            <div key={idx} className="card-dark p-3 rounded-xl mb-3">
              <div className="flex items-center gap-2 mb-2">
                <input
                  type="text"
                  placeholder="Nome do alimento"
                  value={al.nome}
                  onChange={e => updateAlimento(idx, 'nome', e.target.value)}
                  className="flex-1 px-3 py-2 rounded-lg text-white font-dm text-sm outline-none"
                  style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
                />
                <button onClick={() => removeAlimento(idx)} className="text-gray-600 p-1">✕</button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: 'Qtd (g)', field: 'quantidade' as keyof Alimento },
                  { label: 'Calorias', field: 'calorias' as keyof Alimento },
                  { label: 'Proteínas (g)', field: 'proteinas' as keyof Alimento },
                  { label: 'Carboidratos (g)', field: 'carboidratos' as keyof Alimento },
                  { label: 'Gorduras (g)', field: 'gorduras' as keyof Alimento },
                ].map(({ label, field }) => (
                  <div key={field}>
                    <p className="text-xs font-dm text-gray-600 mb-1">{label}</p>
                    <input
                      type="number"
                      value={(al[field] as number) || 0}
                      onChange={e => updateAlimento(idx, field, parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1.5 rounded-lg text-white font-dm text-sm outline-none"
                      style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
                    />
                  </div>
                ))}
              </div>
            </div>
          ))}

          <button onClick={addAlimento} className="w-full py-3 rounded-xl text-sm font-dm mb-4" style={{ border: '1px dashed #2A2A2A', color: '#555' }}>
            + Adicionar alimento
          </button>

          {/* Totais */}
          <div className="card-dark p-4 rounded-xl mb-4">
            <p className="text-xs font-dm text-gray-500 mb-3">TOTAIS DA REFEIÇÃO</p>
            <div className="grid grid-cols-4 gap-2">
              {[
                { label: 'CAL', value: totaisAdicionando.calorias, color: '#00BFFF' },
                { label: 'PROT', value: `${totaisAdicionando.proteinas}g`, color: '#00BFFF' },
                { label: 'CARB', value: `${totaisAdicionando.carboidratos}g`, color: '#00E5FF' },
                { label: 'GORD', value: `${totaisAdicionando.gorduras}g`, color: '#0080FF' },
              ].map(item => (
                <div key={item.label} className="text-center">
                  <p className="font-bebas text-lg" style={{ color: item.color, fontFamily: "'Bebas Neue', sans-serif" }}>{item.value}</p>
                  <p className="text-xs font-dm" style={{ color: '#555' }}>{item.label}</p>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={salvarRefeicao}
            className="w-full py-4 rounded-xl font-bebas text-xl tracking-widest text-white gradient-blue mb-8"
            style={{ fontFamily: "'Bebas Neue', sans-serif" }}
          >
            SALVAR NO DIÁRIO
          </button>
        </div>
      )}

      {aba === 'diario' && (
        <div className="flex-1 overflow-y-auto">
          {/* Days scroller */}
          <div className="flex gap-2 px-4 py-3 overflow-x-auto scrollbar-hide" style={{ borderBottom: '1px solid #1a1a1a' }}>
            {diasRecentes.map(d => (
              <button
                key={d}
                onClick={() => setDataSelecionada(d)}
                className="shrink-0 px-3 py-2 rounded-xl text-center transition-all"
                style={{
                  background: dataSelecionada === d ? 'rgba(0,191,255,0.15)' : '#141414',
                  border: `1px solid ${dataSelecionada === d ? '#00BFFF' : '#2A2A2A'}`,
                  color: dataSelecionada === d ? '#00BFFF' : '#888',
                  minWidth: '52px',
                }}
              >
                <p className="text-xs font-dm">{formatData(d)}</p>
              </button>
            ))}
          </div>

          <div className="px-4 py-3">
            {/* Daily summary */}
            <div className="card-dark p-4 rounded-xl mb-4">
              <div className="flex justify-between items-center mb-3">
                <p className="text-xs font-dm text-gray-500">CALORIAS HOJE</p>
                <p className="font-bebas text-sm" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>
                  Meta: {metaCalorias}
                </p>
              </div>
              <div className="flex items-end gap-2 mb-3">
                <p className="font-bebas text-4xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>
                  {Math.round(totaisHoje.calorias)}
                </p>
                <p className="text-sm font-dm text-gray-500 mb-1">/ {metaCalorias} kcal</p>
              </div>
              <div className="h-2 rounded-full overflow-hidden mb-4" style={{ background: '#1a1a1a' }}>
                <motion.div
                  className="h-full rounded-full"
                  style={{ background: 'linear-gradient(90deg, #00BFFF, #0080FF)' }}
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(100, (totaisHoje.calorias / metaCalorias) * 100)}%` }}
                />
              </div>

              {/* Macros */}
              {[
                { label: 'Proteínas', value: totaisHoje.proteinas, unit: 'g', color: '#00BFFF', max: resultado?.proteina || 150 },
                { label: 'Carboidratos', value: totaisHoje.carboidratos, unit: 'g', color: '#00E5FF', max: resultado?.carbo || 200 },
                { label: 'Gorduras', value: totaisHoje.gorduras, unit: 'g', color: '#0080FF', max: resultado?.gordura || 60 },
              ].map(m => (
                <div key={m.label} className="mb-2">
                  <div className="flex justify-between text-xs font-dm mb-1">
                    <span style={{ color: '#555' }}>{m.label}</span>
                    <span style={{ color: m.color }}>{Math.round(m.value)}{m.unit}</span>
                  </div>
                  <div className="h-1.5 rounded-full overflow-hidden" style={{ background: '#1a1a1a' }}>
                    <div className="h-full rounded-full transition-all" style={{ width: `${Math.min(100, (m.value / m.max) * 100)}%`, background: m.color }} />
                  </div>
                </div>
              ))}
            </div>

            {/* Meals list */}
            {refeicoesDia.length === 0 ? (
              <div className="flex flex-col items-center py-10 text-center">
                <span className="text-5xl mb-3">🥗</span>
                <p className="font-dm text-gray-500 text-sm">Nenhuma refeição registrada hoje.</p>
                <button onClick={() => setAba('adicionar')} className="mt-3 text-sm font-dm" style={{ color: '#00BFFF' }}>
                  Adicionar refeição →
                </button>
              </div>
            ) : (
              <div className="space-y-2 pb-8">
                {refeicoesDia.map((ref, i) => {
                  const t = JSON.parse(ref.totais || '{}');
                  return (
                    <div key={i} className="card-dark p-4 rounded-xl">
                      <div className="flex justify-between items-center mb-2">
                        <div>
                          <p className="font-dm font-bold text-white text-sm">{ref.nome_refeicao}</p>
                          <p className="text-xs font-dm text-gray-500">{ref.horario}</p>
                        </div>
                        <p className="font-bebas text-xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>
                          {Math.round(t.calorias)} kcal
                        </p>
                      </div>
                      <div className="flex gap-3 text-xs font-dm" style={{ color: '#555' }}>
                        <span>P: {Math.round(t.proteinas)}g</span>
                        <span>C: {Math.round(t.carboidratos)}g</span>
                        <span>G: {Math.round(t.gorduras)}g</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {aba === 'dieta' && (
        <div className="flex-1 overflow-y-auto px-4 py-4 pb-8">
          <p className="text-xs font-dm text-gray-500 mb-4">Calcule suas necessidades calóricas:</p>

          <div className="space-y-3 mb-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-xs font-dm text-gray-500 mb-1">Peso (kg)</p>
                <input
                  type="number"
                  value={peso}
                  onChange={e => setPeso(parseFloat(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl text-white font-dm text-sm outline-none"
                  style={{ background: '#141414', border: '1px solid #2A2A2A' }}
                />
              </div>
              <div>
                <p className="text-xs font-dm text-gray-500 mb-1">Altura (cm)</p>
                <input
                  type="number"
                  value={altura}
                  onChange={e => setAltura(parseFloat(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl text-white font-dm text-sm outline-none"
                  style={{ background: '#141414', border: '1px solid #2A2A2A' }}
                />
              </div>
              <div>
                <p className="text-xs font-dm text-gray-500 mb-1">Idade</p>
                <input
                  type="number"
                  value={idade}
                  onChange={e => setIdade(parseInt(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl text-white font-dm text-sm outline-none"
                  style={{ background: '#141414', border: '1px solid #2A2A2A' }}
                />
              </div>
              <div>
                <p className="text-xs font-dm text-gray-500 mb-1">Sexo</p>
                <select
                  value={sexo}
                  onChange={e => setSexo(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-white font-dm text-sm outline-none"
                  style={{ background: '#141414', border: '1px solid #2A2A2A' }}
                >
                  <option value="masculino">Masculino</option>
                  <option value="feminino">Feminino</option>
                </select>
              </div>
            </div>

            <div>
              <p className="text-xs font-dm text-gray-500 mb-1">Nível de atividade</p>
              <select
                value={nivel}
                onChange={e => setNivel(e.target.value)}
                className="w-full px-3 py-2 rounded-xl text-white font-dm text-sm outline-none"
                style={{ background: '#141414', border: '1px solid #2A2A2A' }}
              >
                {NIVEIS.map(n => <option key={n} value={n}>{n}</option>)}
              </select>
            </div>

            <div>
              <p className="text-xs font-dm text-gray-500 mb-1">Objetivo</p>
              <div className="flex flex-col gap-2">
                {OBJETIVOS.map(obj => (
                  <button
                    key={obj}
                    onClick={() => setObjetivo(obj)}
                    className="px-4 py-2 rounded-xl text-sm font-dm text-left transition-all"
                    style={{
                      background: objetivo === obj ? 'rgba(0,191,255,0.15)' : '#141414',
                      border: `1px solid ${objetivo === obj ? '#00BFFF' : '#2A2A2A'}`,
                      color: objetivo === obj ? '#00BFFF' : '#888',
                    }}
                  >
                    {obj}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={calcularDieta}
            className="w-full py-4 rounded-xl font-bebas text-xl tracking-widest text-white gradient-blue mb-4"
            style={{ fontFamily: "'Bebas Neue', sans-serif" }}
          >
            CALCULAR
          </button>

          {resultado && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <div className="grid grid-cols-2 gap-3 mb-4">
                {[
                  { label: 'Calorias', value: resultado.calorias, unit: 'kcal', color: '#00BFFF' },
                  { label: 'Proteínas', value: resultado.proteina, unit: 'g', color: '#00BFFF' },
                  { label: 'Carboidratos', value: resultado.carbo, unit: 'g', color: '#00E5FF' },
                  { label: 'Gorduras', value: resultado.gordura, unit: 'g', color: '#0080FF' },
                ].map(item => (
                  <div key={item.label} className="card-dark p-4 rounded-xl text-center">
                    <p className="font-bebas text-3xl" style={{ color: item.color, fontFamily: "'Bebas Neue', sans-serif" }}>
                      {item.value}{item.unit}
                    </p>
                    <p className="text-xs font-dm text-gray-500">{item.label}</p>
                  </div>
                ))}
              </div>

              <div className="card-dark p-4 rounded-xl">
                <p className="text-xs font-dm text-gray-500 mb-3">DISTRIBUIÇÃO EM 5 REFEIÇÕES</p>
                {[1, 2, 3, 4, 5].map(n => (
                  <div key={n} className="flex justify-between items-center py-2" style={{ borderBottom: n < 5 ? '1px solid #1a1a1a' : 'none' }}>
                    <p className="text-sm font-dm text-white">Refeição {n}</p>
                    <p className="text-sm font-dm" style={{ color: '#00BFFF' }}>
                      ~{Math.round(resultado.calorias / 5)} kcal
                    </p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      )}
    </div>
  );
}
