import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { db } from '../../db/database';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

type TipoCardio = 'Escada' | 'Esteira' | 'Elíptico' | 'Bike';
type Aba = 'sessao' | 'historico';

const TIPOS: { tipo: TipoCardio; icon: string; color: string; desc: string }[] = [
  { tipo: 'Escada', icon: '🏃', color: '#00BFFF', desc: 'Subida de escadas' },
  { tipo: 'Esteira', icon: '🏃‍♂️', color: '#00E5FF', desc: 'Corrida / caminhada' },
  { tipo: 'Elíptico', icon: '🔄', color: '#00FFD1', desc: 'Movimento elíptico' },
  { tipo: 'Bike', icon: '🚲', color: '#0080FF', desc: 'Bicicleta ergométrica' },
];

export default function CardioModule({ onBack }: { onBack: () => void }) {
  const [aba, setAba] = useState<Aba>('sessao');
  const [tipoSelecionado, setTipoSelecionado] = useState<TipoCardio | null>(null);
  const [sessaoAtiva, setSessaoAtiva] = useState(false);
  const [pausado, setPausado] = useState(false);
  const [segundos, setSegundos] = useState(0);
  const [calorias, setCalorias] = useState(0);
  const [bpm, setBpm] = useState(0);
  const [historico, setHistorico] = useState<any[]>([]);
  const [sessaoFinalizada, setSessaoFinalizada] = useState(false);
  const [resumo, setResumo] = useState<any>(null);
  const [watchConectado, setWatchConectado] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startTimeRef = useRef<Date | null>(null);
  const caloriasRef = useRef(0);
  const bpmRef = useRef(0);
  const bpmReadingsRef = useRef<number[]>([]);

  useEffect(() => {
    loadHistorico();
  }, []);

  const loadHistorico = async () => {
    const sessions = await db.sessoes_cardio.orderBy('data').reverse().toArray();
    setHistorico(sessions);
  };

  useEffect(() => {
    if (sessaoAtiva && !pausado) {
      timerRef.current = setInterval(() => {
        setSegundos(s => s + 1);
        // Simulate HealthKit data (in real app would use @capacitor-community/health)
        const variation = (Math.random() - 0.5) * 4;
        const newBpm = Math.round(140 + variation + Math.sin(Date.now() / 10000) * 15);
        setBpm(newBpm);
        bpmReadingsRef.current.push(newBpm);
        bpmRef.current = newBpm;

        // Simulate calories (approx 8-12 cal/min)
        const calPerSec = (9 + Math.random() * 3) / 60;
        caloriasRef.current += calPerSec;
        setCalorias(Math.round(caloriasRef.current));
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [sessaoAtiva, pausado]);

  const iniciarSessao = (tipo: TipoCardio) => {
    setTipoSelecionado(tipo);
    setSessaoAtiva(true);
    startTimeRef.current = new Date();
    caloriasRef.current = 0;
    bpmReadingsRef.current = [];
    setSegundos(0);
    setCalorias(0);
    setBpm(0);
    setSessaoFinalizada(false);

    // Simulate watch connection
    setTimeout(() => setWatchConectado(true), 1500);
  };

  const finalizarSessao = async () => {
    setSessaoAtiva(false);
    if (timerRef.current) clearInterval(timerRef.current);

    const fcMedia = bpmReadingsRef.current.length > 0
      ? Math.round(bpmReadingsRef.current.reduce((a, b) => a + b, 0) / bpmReadingsRef.current.length)
      : 0;
    const calPorMin = segundos > 0 ? parseFloat((caloriasRef.current / (segundos / 60)).toFixed(1)) : 0;

    const resumoData = {
      data: new Date().toISOString().split('T')[0],
      tipo_cardio: tipoSelecionado!,
      duracao_segundos: segundos,
      calorias_totais: Math.round(caloriasRef.current),
      fc_media: fcMedia,
      calorias_por_minuto: calPorMin,
    };

    await db.sessoes_cardio.add(resumoData);
    setResumo(resumoData);
    setSessaoFinalizada(true);
    loadHistorico();
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
  };

  const calPorMin = segundos > 0 ? (calorias / (segundos / 60)).toFixed(1) : '0.0';
  const tipoAtual = TIPOS.find(t => t.tipo === tipoSelecionado);

  if (sessaoFinalizada && resumo) {
    return (
      <div className="flex flex-col h-full">
        <div className="flex items-center gap-4 px-4 pt-12 pb-4" style={{ borderBottom: '1px solid #1a1a1a' }}>
          <button onClick={() => { setSessaoFinalizada(false); setTipoSelecionado(null); }} className="text-gray-400 p-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M5 12l7 7M5 12l7-7" /></svg>
          </button>
          <h1 className="font-bebas text-3xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>RESUMO</h1>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center p-6 gap-6">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring' }} className="text-6xl">
            🎉
          </motion.div>
          <h2 className="font-bebas text-4xl text-white" style={{ fontFamily: "'Bebas Neue', sans-serif" }}>{resumo.tipo_cardio}</h2>
          <div className="grid grid-cols-2 gap-4 w-full">
            {[
              { label: 'DURAÇÃO', value: formatTime(resumo.duracao_segundos), unit: '' },
              { label: 'CALORIAS', value: resumo.calorias_totais, unit: 'kcal' },
              { label: 'FC MÉDIA', value: resumo.fc_media, unit: 'bpm' },
              { label: 'CAL/MIN', value: resumo.calorias_por_minuto, unit: '/min' },
            ].map(item => (
              <div key={item.label} className="card-dark p-4 rounded-xl text-center">
                <p className="font-bebas text-3xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>
                  {item.value}{item.unit}
                </p>
                <p className="text-xs font-dm text-gray-500">{item.label}</p>
              </div>
            ))}
          </div>
          <button
            onClick={() => { setSessaoFinalizada(false); setTipoSelecionado(null); }}
            className="w-full py-4 rounded-xl font-bebas text-xl tracking-widest text-white gradient-blue"
            style={{ fontFamily: "'Bebas Neue', sans-serif" }}
          >
            VOLTAR
          </button>
        </div>
      </div>
    );
  }

  if (sessaoAtiva && tipoSelecionado) {
    return (
      <div className="flex flex-col h-full">
        <div className="flex items-center gap-4 px-4 pt-12 pb-4" style={{ borderBottom: '1px solid #1a1a1a' }}>
          <h1 className="font-bebas text-3xl" style={{ color: tipoAtual?.color, fontFamily: "'Bebas Neue', sans-serif" }}>
            {tipoSelecionado.toUpperCase()}
          </h1>
          <div className="ml-auto flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${watchConectado ? 'bg-green-400' : 'bg-gray-600'}`} />
            <span className="text-xs font-dm text-gray-500">{watchConectado ? 'Watch ⌚' : 'Sem Watch'}</span>
          </div>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center gap-6 px-4">
          {/* Chronometer */}
          <motion.div
            animate={{ scale: pausado ? 0.95 : 1 }}
            className="text-center"
          >
            <p className="font-bebas text-8xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif", letterSpacing: '0.05em' }}>
              {formatTime(segundos)}
            </p>
            {pausado && <p className="text-sm font-dm text-gray-500 mt-2">PAUSADO</p>}
          </motion.div>

          {/* Metrics */}
          <div className="grid grid-cols-3 gap-3 w-full">
            <div className="card-dark p-4 rounded-xl text-center">
              <p className="font-bebas text-3xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>{calorias}</p>
              <p className="text-xs font-dm text-gray-500">KCAL</p>
            </div>
            <div className="card-dark p-4 rounded-xl text-center">
              <p className="font-bebas text-3xl flex items-center justify-center gap-1" style={{ color: '#FF6B6B', fontFamily: "'Bebas Neue', sans-serif" }}>
                <span className="animate-heartbeat inline-block">❤️</span>
                {bpm || '--'}
              </p>
              <p className="text-xs font-dm text-gray-500">BPM</p>
            </div>
            <div className="card-dark p-4 rounded-xl text-center">
              <p className="font-bebas text-3xl" style={{ color: '#00FFD1', fontFamily: "'Bebas Neue', sans-serif" }}>{calPorMin}</p>
              <p className="text-xs font-dm text-gray-500">CAL/MIN</p>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="px-4 pb-8 pt-4 flex gap-3" style={{ borderTop: '1px solid #1a1a1a' }}>
          <button
            onClick={() => setPausado(!pausado)}
            className="flex-1 py-4 rounded-xl font-bebas text-xl tracking-widest"
            style={{ background: '#141414', border: '1px solid #2A2A2A', color: '#888', fontFamily: "'Bebas Neue', sans-serif" }}
          >
            {pausado ? 'CONTINUAR' : 'PAUSAR'}
          </button>
          <button
            onClick={finalizarSessao}
            className="flex-1 py-4 rounded-xl font-bebas text-xl tracking-widest text-white gradient-blue"
            style={{ fontFamily: "'Bebas Neue', sans-serif" }}
          >
            FINALIZAR
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-4 px-4 pt-12 pb-4" style={{ borderBottom: '1px solid #1a1a1a' }}>
        <button onClick={onBack} className="text-gray-400 p-2">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M5 12l7 7M5 12l7-7" /></svg>
        </button>
        <h1 className="font-bebas text-3xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>CARDIO</h1>
        <div className="ml-auto flex gap-1">
          {(['sessao', 'historico'] as Aba[]).map(a => (
            <button
              key={a}
              onClick={() => setAba(a)}
              className="px-3 py-1.5 rounded-lg text-xs font-dm font-medium transition-all"
              style={{
                background: aba === a ? 'rgba(0,191,255,0.15)' : 'transparent',
                color: aba === a ? '#00BFFF' : '#555',
                border: aba === a ? '1px solid rgba(0,191,255,0.3)' : '1px solid transparent',
              }}
            >
              {a === 'sessao' ? 'SESSÃO' : 'HISTÓRICO'}
            </button>
          ))}
        </div>
      </div>

      {aba === 'sessao' ? (
        <div className="flex-1 overflow-y-auto px-4 py-4">
          <p className="text-sm font-dm text-gray-500 mb-4">Selecione o tipo de cardio:</p>
          <div className="grid grid-cols-2 gap-3">
            {TIPOS.map(({ tipo, icon, color, desc }) => (
              <motion.button
                key={tipo}
                whileTap={{ scale: 0.95 }}
                onClick={() => iniciarSessao(tipo)}
                className="p-6 rounded-2xl flex flex-col items-center gap-3 text-center"
                style={{ background: '#141414', border: `1px solid ${color}33` }}
              >
                <span className="text-5xl">{icon}</span>
                <div>
                  <p className="font-bebas text-xl" style={{ color, fontFamily: "'Bebas Neue', sans-serif" }}>{tipo.toUpperCase()}</p>
                  <p className="text-xs font-dm text-gray-500">{desc}</p>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto px-4 py-4">
          {historico.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <span className="text-5xl mb-4">📊</span>
              <p className="font-dm text-gray-500">Nenhuma sessão registrada ainda.</p>
            </div>
          ) : (
            <>
              {/* Chart */}
              <div className="card-dark p-4 rounded-xl mb-4">
                <p className="text-xs font-dm text-gray-500 mb-3">Calorias por sessão</p>
                <ResponsiveContainer width="100%" height={150}>
                  <LineChart data={historico.slice(0, 10).reverse().map(s => ({ data: s.data.slice(5), cal: s.calorias_totais }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                    <XAxis dataKey="data" tick={{ fill: '#555', fontSize: 10 }} />
                    <YAxis tick={{ fill: '#555', fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: '#141414', border: '1px solid #2A2A2A', borderRadius: 8 }} />
                    <Line type="monotone" dataKey="cal" stroke="#00BFFF" strokeWidth={2} dot={{ fill: '#00BFFF', r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="space-y-2">
                {historico.map((s, i) => (
                  <div key={i} className="card-dark p-4 rounded-xl flex items-center justify-between">
                    <div>
                      <p className="font-dm font-bold text-white text-sm">{s.tipo_cardio}</p>
                      <p className="text-xs font-dm text-gray-500">{s.data} · {formatTime(s.duracao_segundos)}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bebas text-xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>{s.calorias_totais}</p>
                      <p className="text-xs font-dm text-gray-500">kcal</p>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
