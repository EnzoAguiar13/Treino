import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { db, getExerciciosDoDia, getSeriesDoDia, getUltimaSerie, Exercicio, TreinoDia, Serie } from '../../db/database';

const DIAS = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];
const DIAS_TREINO = ['Segunda', 'Terça', 'Quarta', 'Sexta', 'Sábado'];
const GRUPOS_MUSCULARES = ['Costas', 'Peito', 'Pernas', 'Ombro', 'Bíceps', 'Tríceps', 'Abdômen', 'Cardio', 'Posterior de Ombro'];

const getDiaSemanaAtual = () => {
  const dias = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
  return dias[new Date().getDay()];
};

const hoje = new Date().toISOString().split('T')[0];



interface SerieLocal {
  tempId: string;
  peso_kg: number;
  repeticoes: number;
  concluida: boolean;
  muscle_round: boolean;
  observacao: string;
  ordem: number;
  dbId?: number;
}

export default function TreinoModule({ onBack }: { onBack: () => void }) {
  const [diaSelecionado, setDiaSelecionado] = useState(() => {
    const atual = getDiaSemanaAtual();
    return DIAS_TREINO.includes(atual) ? atual : 'Segunda';
  });
  const [exercicios, setExercicios] = useState<{ treino: TreinoDia; exercicio: Exercicio }[]>([]);
  const [exercicioAtivo, setExercicioAtivo] = useState<{ treino: TreinoDia; exercicio: Exercicio } | null>(null);
  const [seriesMap, setSeriesMap] = useState<Record<number, SerieLocal[]>>({});
  const [ultimasCargas, setUltimasCargas] = useState<Record<number, number>>({});
  const [treinoIniciado, setTreinoIniciado] = useState(false);
  const [exerciciosConcluidos, setExerciciosConcluidos] = useState<Set<number>>(new Set());
  const [timerAtivo, setTimerAtivo] = useState(false);
  const [timerSegundos, setTimerSegundos] = useState(90);
  const [timerTotal, setTimerTotal] = useState(90);
  const [treinoConcluido, setTreinoConcluido] = useState(false);
  const [showAddExercicio, setShowAddExercicio] = useState(false);
  const [showTrocarModal, setShowTrocarModal] = useState(false);
  const [exercicioParaTrocar, setExercicioParaTrocar] = useState<{ treino: TreinoDia; exercicio: Exercicio } | null>(null);
  const [buscaExercicio, setBuscaExercicio] = useState('');
  const [todosExercicios, setTodosExercicios] = useState<Exercicio[]>([]);
  const [novoExNome, setNovoExNome] = useState('');
  const [novoExGrupo, setNovoExGrupo] = useState('Costas');
  const [inicioTreino, setInicioTreino] = useState<Date | null>(null);
  const [observacoes, setObservacoes] = useState<Record<number, string>>({});
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [incremento, setIncremento] = useState(2.5);
  const saveTimeouts = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  useEffect(() => {
    db.usuario.toArray().then(u => {
      if (u[0]) setIncremento(u[0].incremento_peso_padrao || 2.5);
    });
    db.usuario.toArray().then(u => {
      if (u[0]) setTimerTotal(u[0].timer_descanso_padrao || 90);
    });
  }, []);

  useEffect(() => {
    loadExercicios();
  }, [diaSelecionado]);

  const loadExercicios = async () => {
    const exs = await getExerciciosDoDia(diaSelecionado);
    setExercicios(exs);

    const cargas: Record<number, number> = {};
    const series: Record<number, SerieLocal[]> = {};

    for (const { exercicio, treino } of exs) {
      if (!exercicio.id) continue;
      const ultima = await getUltimaSerie(exercicio.id, diaSelecionado);
      if (ultima) cargas[exercicio.id] = ultima.peso_kg;

      const seriesHoje = await getSeriesDoDia(exercicio.id, diaSelecionado, hoje);
      if (seriesHoje.length > 0) {
        series[treino.id!] = seriesHoje.map(s => ({
          tempId: `s_${s.id}`,
          peso_kg: s.peso_kg,
          repeticoes: s.repeticoes,
          concluida: s.concluida,
          muscle_round: s.muscle_round,
          observacao: s.observacao,
          ordem: s.ordem,
          dbId: s.id,
        }));
      } else {
        const pesoSugerido = ultima?.peso_kg ?? 60;
        const repsSugeridas = ultima?.repeticoes ?? 8;
        series[treino.id!] = [
          { tempId: `t${treino.id}_0`, peso_kg: pesoSugerido, repeticoes: repsSugeridas, concluida: false, muscle_round: false, observacao: '', ordem: 0 },
          { tempId: `t${treino.id}_1`, peso_kg: pesoSugerido, repeticoes: repsSugeridas, concluida: false, muscle_round: false, observacao: '', ordem: 1 },
          { tempId: `t${treino.id}_2`, peso_kg: pesoSugerido, repeticoes: repsSugeridas, concluida: false, muscle_round: false, observacao: '', ordem: 2 },
        ];
      }
    }

    setUltimasCargas(cargas);
    setSeriesMap(series);
  };

  const debounceSave = useCallback((key: string, fn: () => void) => {
    if (saveTimeouts.current[key]) clearTimeout(saveTimeouts.current[key]);
    saveTimeouts.current[key] = setTimeout(fn, 500);
  }, []);

  const saveSerie = useCallback(async (exercicioId: number, _treinoId: number, serie: SerieLocal) => {
    const data: Omit<Serie, 'id'> = {
      exercicio_id: exercicioId,
      data: hoje,
      peso_kg: serie.peso_kg,
      repeticoes: serie.repeticoes,
      muscle_round: serie.muscle_round,
      concluida: serie.concluida,
      observacao: serie.observacao,
      ordem: serie.ordem,
      treino_dia: diaSelecionado,
    };

    if (serie.dbId) {
      await db.series.update(serie.dbId, data);
    } else {
      const id = await db.series.add(data);
      return id as number;
    }
  }, [diaSelecionado]);

  const updateSerie = useCallback((treinoId: number, exercicioId: number, tempId: string, field: keyof SerieLocal, value: number | boolean | string) => {
    setSeriesMap(prev => {
      const series = prev[treinoId] || [];
      const updated = series.map(s => s.tempId === tempId ? { ...s, [field]: value } : s);
      const updatedSerie = updated.find(s => s.tempId === tempId);
      if (updatedSerie && (field === 'peso_kg' || field === 'repeticoes' || field === 'concluida' || field === 'muscle_round')) {
        debounceSave(`${treinoId}_${tempId}`, () => saveSerie(exercicioId, 0, updatedSerie));
      }
      return { ...prev, [treinoId]: updated };
    });

    if (field === 'concluida' && value === true && timerAtivo === false) {
      startTimer();
    }
  }, [debounceSave, saveSerie, timerAtivo]);

  const startTimer = useCallback(() => {
    db.usuario.toArray().then(u => {
      const dur = u[0]?.timer_descanso_padrao || 90;
      setTimerSegundos(dur);
      setTimerTotal(dur);
      setTimerAtivo(true);
    });
  }, []);

  useEffect(() => {
    if (timerAtivo && timerSegundos > 0) {
      timerRef.current = setInterval(() => {
        setTimerSegundos(s => {
          if (s <= 1) {
            setTimerAtivo(false);
            clearInterval(timerRef.current!);
            if ('vibrate' in navigator) navigator.vibrate([200, 100, 200]);
            return 0;
          }
          return s - 1;
        });
      }, 1000);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [timerAtivo]);

  const addSerie = (treinoId: number, _exercicioId: number) => {
    setSeriesMap(prev => {
      const series = prev[treinoId] || [];
      const ultima = series[series.length - 1];
      const nova: SerieLocal = {
        tempId: `t${treinoId}_${Date.now()}`,
        peso_kg: ultima?.peso_kg ?? 60,
        repeticoes: ultima?.repeticoes ?? 8,
        concluida: false,
        muscle_round: false,
        observacao: '',
        ordem: series.length,
      };
      return { ...prev, [treinoId]: [...series, nova] };
    });
  };

  const removeSerie = async (treinoId: number, tempId: string) => {
    setSeriesMap(prev => {
      const series = prev[treinoId] || [];
      const target = series.find(s => s.tempId === tempId);
      if (target?.dbId) db.series.delete(target.dbId);
      return { ...prev, [treinoId]: series.filter(s => s.tempId !== tempId) };
    });
  };

  const concluirExercicio = (treinoId: number) => {
    setExerciciosConcluidos(prev => new Set([...prev, treinoId]));
    if (exerciciosConcluidos.size + 1 >= exercicios.length) {
      setTreinoConcluido(true);
    }
    setExercicioAtivo(null);
  };

  const handleTrocarExercicio = async (novoExercicio: Exercicio) => {
    if (!exercicioParaTrocar || !novoExercicio.id) return;
    await db.treino_dias.update(exercicioParaTrocar.treino.id!, { exercicio_id: novoExercicio.id });
    setShowTrocarModal(false);
    loadExercicios();
  };

  const adicionarExercicioCustom = async () => {
    if (!novoExNome.trim()) return;
    const id = await db.exercicios.add({ nome: novoExNome, grupo_muscular: novoExGrupo, criado_por_usuario: true });
    await db.treino_dias.add({ dia_semana: diaSelecionado, exercicio_id: id as number, ordem: exercicios.length });
    setNovoExNome('');
    setShowAddExercicio(false);
    loadExercicios();
  };

  const totalConcluidos = exerciciosConcluidos.size;
  const totalExercicios = exercicios.length;

  if (treinoConcluido) {
    const duracao = inicioTreino ? Math.round((Date.now() - inicioTreino.getTime()) / 60000) : 0;
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed inset-0 flex flex-col items-center justify-center p-6"
        style={{ background: '#0A0A0A' }}
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', damping: 10 }}
          className="text-8xl mb-6"
        >
          🏆
        </motion.div>
        <h2 className="font-bebas text-5xl glow-blue mb-2" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>
          TREINO CONCLUÍDO!
        </h2>
        <p className="text-gray-400 mb-8 font-dm">{diaSelecionado} — {hoje}</p>
        <div className="grid grid-cols-2 gap-4 w-full max-w-xs mb-8">
          <div className="card-dark p-4 text-center rounded-xl">
            <p className="text-2xl font-bebas" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>{totalExercicios}</p>
            <p className="text-xs text-gray-500 font-dm">Exercícios</p>
          </div>
          <div className="card-dark p-4 text-center rounded-xl">
            <p className="text-2xl font-bebas" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>{duracao}min</p>
            <p className="text-xs text-gray-500 font-dm">Duração</p>
          </div>
        </div>
        <button
          onClick={() => { setTreinoConcluido(false); setExerciciosConcluidos(new Set()); onBack(); }}
          className="gradient-blue px-8 py-4 rounded-xl font-bebas text-xl tracking-widest text-white"
          style={{ fontFamily: "'Bebas Neue', sans-serif" }}
        >
          VOLTAR AO UNIVERSO
        </button>
      </motion.div>
    );
  }

  if (exercicioAtivo) {
    const seriesDoEx = seriesMap[exercicioAtivo.treino.id!] || [];
    const ultimaCarga = ultimasCargas[exercicioAtivo.exercicio.id!];

    return (
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 20 }}
        className="fixed inset-0 flex flex-col"
        style={{ background: '#0A0A0A' }}
      >
        {/* Header */}
        <div className="flex items-center gap-4 px-4 pt-12 pb-4" style={{ borderBottom: '1px solid #1a1a1a' }}>
          <button onClick={() => setExercicioAtivo(null)} className="text-gray-400 p-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M19 12H5M5 12l7 7M5 12l7-7" />
            </svg>
          </button>
          <div className="flex-1">
            <h2 className="font-bebas text-2xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>
              {exercicioAtivo.exercicio.nome.toUpperCase()}
            </h2>
            <p className="text-xs font-dm" style={{ color: '#555' }}>
              {exercicioAtivo.exercicio.grupo_muscular} · Registre apenas séries de trabalho
            </p>
          </div>
          {ultimaCarga && (
            <span className="text-xs font-dm px-2 py-1 rounded-lg" style={{ color: '#00BFFF', background: 'rgba(0,191,255,0.1)', border: '1px solid rgba(0,191,255,0.2)' }}>
              Última: {ultimaCarga}kg
            </span>
          )}
        </div>

        {/* Timer */}
        {timerAtivo && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-4 mt-3 p-3 rounded-xl flex items-center gap-4"
            style={{ background: 'rgba(0,191,255,0.1)', border: '1px solid rgba(0,191,255,0.3)' }}
          >
            <div className="relative w-12 h-12">
              <svg className="w-12 h-12 -rotate-90" viewBox="0 0 44 44">
                <circle cx="22" cy="22" r="18" fill="none" stroke="#1a1a1a" strokeWidth="3" />
                <circle
                  cx="22" cy="22" r="18" fill="none" stroke="#00BFFF" strokeWidth="3"
                  strokeDasharray={`${2 * Math.PI * 18}`}
                  strokeDashoffset={`${2 * Math.PI * 18 * (1 - timerSegundos / timerTotal)}`}
                  strokeLinecap="round"
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-xs font-bebas" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>
                {timerSegundos}
              </span>
            </div>
            <div>
              <p className="text-sm font-dm font-bold" style={{ color: '#00BFFF' }}>DESCANSO</p>
              <p className="text-xs font-dm text-gray-500">{timerSegundos}s restantes</p>
            </div>
            <button onClick={() => setTimerAtivo(false)} className="ml-auto text-gray-500 text-xs font-dm">Pular</button>
          </motion.div>
        )}

        {/* Series list */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
          {seriesDoEx.map((serie, idx) => (
            <motion.div
              key={serie.tempId}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="rounded-xl p-3 flex items-center gap-2"
              style={{
                background: serie.concluida ? 'rgba(0,191,255,0.08)' : '#141414',
                border: `1px solid ${serie.muscle_round ? '#00BFFF' : serie.concluida ? 'rgba(0,191,255,0.4)' : '#2A2A2A'}`,
                boxShadow: serie.muscle_round ? '0 0 10px rgba(0,191,255,0.3)' : 'none',
              }}
            >
              <span className="font-bebas text-sm w-7 shrink-0" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>
                S{idx + 1}
              </span>

              {/* Peso */}
              <div className="flex items-center gap-1">
                <button
                  onClick={() => updateSerie(exercicioAtivo.treino.id!, exercicioAtivo.exercicio.id!, serie.tempId, 'peso_kg', Math.max(0, serie.peso_kg - incremento))}
                  className="w-7 h-7 rounded-lg text-sm font-bold"
                  style={{ background: '#1a1a1a', color: '#00BFFF', border: '1px solid #2A2A2A' }}
                >−</button>
                <input
                  type="number"
                  value={serie.peso_kg}
                  onChange={e => updateSerie(exercicioAtivo.treino.id!, exercicioAtivo.exercicio.id!, serie.tempId, 'peso_kg', parseFloat(e.target.value) || 0)}
                  className="w-14 text-center text-sm font-bold font-dm bg-transparent outline-none text-white"
                />
                <button
                  onClick={() => updateSerie(exercicioAtivo.treino.id!, exercicioAtivo.exercicio.id!, serie.tempId, 'peso_kg', serie.peso_kg + incremento)}
                  className="w-7 h-7 rounded-lg text-sm font-bold"
                  style={{ background: '#1a1a1a', color: '#00BFFF', border: '1px solid #2A2A2A' }}
                >+</button>
                <span className="text-xs text-gray-500 font-dm">kg</span>
              </div>

              {/* Reps */}
              <div className="flex items-center gap-1">
                <button
                  onClick={() => updateSerie(exercicioAtivo.treino.id!, exercicioAtivo.exercicio.id!, serie.tempId, 'repeticoes', Math.max(1, serie.repeticoes - 1))}
                  className="w-7 h-7 rounded-lg text-sm font-bold"
                  style={{ background: '#1a1a1a', color: '#00BFFF', border: '1px solid #2A2A2A' }}
                >−</button>
                <input
                  type="number"
                  value={serie.repeticoes}
                  onChange={e => updateSerie(exercicioAtivo.treino.id!, exercicioAtivo.exercicio.id!, serie.tempId, 'repeticoes', parseInt(e.target.value) || 1)}
                  className="w-10 text-center text-sm font-bold font-dm bg-transparent outline-none text-white"
                />
                <button
                  onClick={() => updateSerie(exercicioAtivo.treino.id!, exercicioAtivo.exercicio.id!, serie.tempId, 'repeticoes', serie.repeticoes + 1)}
                  className="w-7 h-7 rounded-lg text-sm font-bold"
                  style={{ background: '#1a1a1a', color: '#00BFFF', border: '1px solid #2A2A2A' }}
                >+</button>
                <span className="text-xs text-gray-500 font-dm">×</span>
              </div>

              {/* MR */}
              <button
                onClick={() => updateSerie(exercicioAtivo.treino.id!, exercicioAtivo.exercicio.id!, serie.tempId, 'muscle_round', !serie.muscle_round)}
                className="text-xs font-dm px-1.5 py-0.5 rounded"
                style={{
                  color: serie.muscle_round ? '#00BFFF' : '#444',
                  border: `1px solid ${serie.muscle_round ? '#00BFFF' : '#2A2A2A'}`,
                  background: serie.muscle_round ? 'rgba(0,191,255,0.1)' : 'transparent',
                  fontSize: '0.6rem',
                }}
              >MR</button>

              {/* Check */}
              <button
                onClick={() => updateSerie(exercicioAtivo.treino.id!, exercicioAtivo.exercicio.id!, serie.tempId, 'concluida', !serie.concluida)}
                className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                style={{
                  background: serie.concluida ? '#00BFFF' : '#1a1a1a',
                  border: `1px solid ${serie.concluida ? '#00BFFF' : '#2A2A2A'}`,
                }}
              >
                {serie.concluida && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><polyline points="20 6 9 17 4 12" /></svg>}
              </button>

              {/* Delete */}
              <button onClick={() => removeSerie(exercicioAtivo.treino.id!, serie.tempId)} className="shrink-0 text-gray-600 hover:text-red-400 transition-colors">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" /></svg>
              </button>
            </motion.div>
          ))}

          {/* Add serie button */}
          <button
            onClick={() => addSerie(exercicioAtivo.treino.id!, exercicioAtivo.exercicio.id!)}
            className="w-full py-3 rounded-xl text-sm font-dm font-medium transition-all"
            style={{ border: '1px dashed #00BFFF', color: '#00BFFF', background: 'rgba(0,191,255,0.03)' }}
          >
            + Adicionar série
          </button>

          {/* Observações */}
          <div className="mt-2">
            <textarea
              placeholder="Observações..."
              value={observacoes[exercicioAtivo.exercicio.id!] || ''}
              onChange={e => setObservacoes(prev => ({ ...prev, [exercicioAtivo.exercicio.id!]: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl text-sm font-dm text-gray-300 outline-none resize-none"
              style={{ background: '#141414', border: '1px solid #2A2A2A', color: '#888', minHeight: '80px' }}
              rows={3}
            />
          </div>
        </div>

        {/* Concluir exercício */}
        <div className="px-4 pb-8 pt-3" style={{ borderTop: '1px solid #1a1a1a' }}>
          <button
            onClick={() => concluirExercicio(exercicioAtivo.treino.id!)}
            className="w-full py-4 rounded-xl font-bebas text-xl tracking-widest text-white gradient-blue"
            style={{ fontFamily: "'Bebas Neue', sans-serif" }}
          >
            CONCLUIR EXERCÍCIO ✓
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-4 px-4 pt-12 pb-4" style={{ borderBottom: '1px solid #1a1a1a' }}>
        <button onClick={onBack} className="text-gray-400 p-2">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M19 12H5M5 12l7 7M5 12l7-7" />
          </svg>
        </button>
        <h1 className="font-bebas text-3xl" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>TREINO</h1>
        {treinoIniciado && (
          <div className="ml-auto text-xs font-dm text-gray-400">
            {totalConcluidos}/{totalExercicios}
          </div>
        )}
      </div>

      {/* Progress bar */}
      {treinoIniciado && (
        <div className="h-1 w-full" style={{ background: '#1a1a1a' }}>
          <motion.div
            className="h-full"
            style={{ background: 'linear-gradient(90deg, #00BFFF, #0080FF)' }}
            initial={{ width: 0 }}
            animate={{ width: `${(totalConcluidos / totalExercicios) * 100}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      )}

      {/* Days selector */}
      <div className="px-4 py-3 overflow-x-auto scrollbar-hide">
        <div className="flex gap-2 min-w-max">
          {DIAS.map(dia => {
            const temTreino = DIAS_TREINO.includes(dia);
            const isSelected = dia === diaSelecionado;
            const isHoje = dia === getDiaSemanaAtual();
            return (
              <button
                key={dia}
                onClick={() => temTreino && setDiaSelecionado(dia)}
                className="px-3 py-2 rounded-xl text-sm font-dm font-medium transition-all shrink-0"
                style={{
                  background: isSelected ? 'rgba(0,191,255,0.15)' : '#141414',
                  border: isSelected ? '1px solid #00BFFF' : '1px solid #2A2A2A',
                  color: !temTreino ? '#333' : isSelected ? '#00BFFF' : isHoje ? '#fff' : '#888',
                  boxShadow: isSelected ? '0 0 15px rgba(0,191,255,0.2)' : 'none',
                }}
              >
                <div className="text-xs">{dia.slice(0, 3)}</div>
                {!temTreino && <div className="text-xs" style={{ color: '#333' }}>DESCANSO</div>}
                {isHoje && <div style={{ width: 4, height: 4, borderRadius: '50%', background: isSelected ? '#00BFFF' : '#555', margin: '2px auto 0' }} />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Iniciar treino button */}
      {!treinoIniciado && (
        <div className="px-4 pb-3">
          <button
            onClick={() => { setTreinoIniciado(true); setInicioTreino(new Date()); }}
            className="w-full py-3 rounded-xl font-bebas text-lg tracking-widest text-white gradient-blue"
            style={{ fontFamily: "'Bebas Neue', sans-serif" }}
          >
            INICIAR TREINO
          </button>
        </div>
      )}

      {/* Exercise list */}
      <div className="flex-1 overflow-y-auto px-4 pb-24 space-y-2">
        {exercicios.map(({ treino, exercicio }, idx) => {
          const concluido = exerciciosConcluidos.has(treino.id!);
          const series = seriesMap[treino.id!] || [];
          const ultimaCarga = ultimasCargas[exercicio.id!];

          return (
            <motion.div
              key={treino.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="rounded-xl p-4 cursor-pointer"
              style={{
                background: concluido ? 'rgba(0,191,255,0.05)' : '#141414',
                border: `1px solid ${concluido ? 'rgba(0,191,255,0.4)' : '#2A2A2A'}`,
              }}
              onClick={() => !concluido && setExercicioAtivo({ treino, exercicio })}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {concluido && <span style={{ color: '#00BFFF' }}>✓</span>}
                    <h3 className="font-dm font-bold text-white text-base">{exercicio.nome}</h3>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs px-2 py-0.5 rounded-full font-dm" style={{ color: '#00BFFF', background: 'rgba(0,191,255,0.12)' }}>
                      {exercicio.grupo_muscular}
                    </span>
                    {ultimaCarga && (
                      <span className="text-xs font-dm" style={{ color: '#00BFFF' }}>
                        Última: {ultimaCarga}kg
                      </span>
                    )}
                    <span className="text-xs font-dm text-gray-600">
                      {series.length} séries
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={e => { e.stopPropagation(); setExercicioParaTrocar({ treino, exercicio }); db.exercicios.toArray().then(setTodosExercicios); setShowTrocarModal(true); }}
                    className="p-2 rounded-lg text-gray-500"
                    style={{ background: '#1a1a1a' }}
                  >
                    ⋮
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}

        {/* Add custom exercise */}
        <button
          onClick={() => setShowAddExercicio(true)}
          className="w-full py-3 rounded-xl text-sm font-dm font-medium"
          style={{ border: '1px dashed #2A2A2A', color: '#555' }}
        >
          + Adicionar Exercício
        </button>
      </div>

      {/* Add exercise modal */}
      <AnimatePresence>
        {showAddExercicio && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end"
            style={{ background: 'rgba(0,0,0,0.8)' }}
            onClick={() => setShowAddExercicio(false)}
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="w-full p-6 rounded-t-2xl"
              style={{ background: '#141414', border: '1px solid #2A2A2A' }}
              onClick={e => e.stopPropagation()}
            >
              <h3 className="font-bebas text-2xl mb-4" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>NOVO EXERCÍCIO</h3>
              <input
                type="text"
                placeholder="Nome do exercício"
                value={novoExNome}
                onChange={e => setNovoExNome(e.target.value)}
                className="w-full px-4 py-3 rounded-xl text-white font-dm text-sm outline-none mb-3"
                style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
              />
              <select
                value={novoExGrupo}
                onChange={e => setNovoExGrupo(e.target.value)}
                className="w-full px-4 py-3 rounded-xl text-white font-dm text-sm outline-none mb-4"
                style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
              >
                {GRUPOS_MUSCULARES.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
              <button onClick={adicionarExercicioCustom} className="w-full py-3 rounded-xl font-bebas text-xl tracking-widest text-white gradient-blue" style={{ fontFamily: "'Bebas Neue', sans-serif" }}>
                ADICIONAR
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Trocar exercício modal */}
      <AnimatePresence>
        {showTrocarModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end"
            style={{ background: 'rgba(0,0,0,0.8)' }}
            onClick={() => setShowTrocarModal(false)}
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="w-full p-4 rounded-t-2xl"
              style={{ background: '#141414', border: '1px solid #2A2A2A', maxHeight: '70vh', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}
              onClick={e => e.stopPropagation()}
            >
              <h3 className="font-bebas text-2xl mb-3" style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}>TROCAR EXERCÍCIO</h3>
              <input
                type="text"
                placeholder="Buscar exercício..."
                value={buscaExercicio}
                onChange={e => setBuscaExercicio(e.target.value)}
                className="w-full px-4 py-3 rounded-xl text-white font-dm text-sm outline-none mb-3"
                style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
              />
              <div className="overflow-y-auto flex-1 space-y-2">
                {todosExercicios
                  .filter(ex => ex.nome.toLowerCase().includes(buscaExercicio.toLowerCase()))
                  .map(ex => (
                    <button
                      key={ex.id}
                      onClick={() => handleTrocarExercicio(ex)}
                      className="w-full text-left px-4 py-3 rounded-xl flex items-center gap-3"
                      style={{ background: '#0A0A0A', border: '1px solid #2A2A2A' }}
                    >
                      <span className="font-dm text-white text-sm">{ex.nome}</span>
                      <span className="ml-auto text-xs px-2 py-0.5 rounded-full font-dm" style={{ color: '#00BFFF', background: 'rgba(0,191,255,0.1)' }}>
                        {ex.grupo_muscular}
                      </span>
                    </button>
                  ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
