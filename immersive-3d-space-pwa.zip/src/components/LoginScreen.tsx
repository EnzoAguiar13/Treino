import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface LoginScreenProps {
  onLogin: () => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const stars: { x: number; y: number; r: number; alpha: number; speed: number }[] = [];
    for (let i = 0; i < 200; i++) {
      stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.5 + 0.3,
        alpha: Math.random(),
        speed: Math.random() * 0.005 + 0.002,
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#0A0A0A';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      stars.forEach(star => {
        star.alpha += star.speed;
        if (star.alpha > 1 || star.alpha < 0) star.speed *= -1;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255,255,255,${Math.abs(Math.sin(star.alpha))})`;
        ctx.fill();
      });

      animRef.current = requestAnimationFrame(animate);
    };

    animate();

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resize);

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', resize);
    };
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    await new Promise(r => setTimeout(r, 800));
    
    if (email === 'enzofortes13@gmail.com' && password === 'Pipoca1020*') {
      localStorage.setItem('enzo_session', 'authenticated');
      onLogin();
    } else {
      setError('E-mail ou senha incorretos.');
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center" style={{ background: '#0A0A0A' }}>
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
      
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        className="relative z-10 w-full max-w-sm px-6 flex flex-col items-center"
      >
        {/* Logo */}
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1, ease: 'easeOut' }}
          className="mb-10 text-center"
        >
          <h1
            className="font-bebas text-8xl tracking-wider glow-blue"
            style={{ color: '#00BFFF', fontFamily: "'Bebas Neue', sans-serif" }}
          >
            ENZO
          </h1>
          <p className="text-sm font-dm mt-1" style={{ color: '#888888', letterSpacing: '0.3em' }}>
            FITNESS UNIVERSE
          </p>
        </motion.div>

        {/* Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="w-full rounded-2xl p-6"
          style={{ background: '#141414', border: '1px solid #2A2A2A' }}
        >
          <form onSubmit={handleLogin} className="flex flex-col gap-4">
            <div>
              <label className="text-xs font-dm mb-2 block" style={{ color: '#888888', letterSpacing: '0.1em' }}>
                E-MAIL
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-xl text-white font-dm text-sm outline-none transition-all"
                style={{
                  background: '#0A0A0A',
                  border: '1px solid #2A2A2A',
                }}
                onFocus={e => (e.target.style.borderColor = '#00BFFF')}
                onBlur={e => (e.target.style.borderColor = '#2A2A2A')}
                placeholder="seu@email.com"
                autoComplete="email"
              />
            </div>

            <div>
              <label className="text-xs font-dm mb-2 block" style={{ color: '#888888', letterSpacing: '0.1em' }}>
                SENHA
              </label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-xl text-white font-dm text-sm outline-none transition-all"
                style={{
                  background: '#0A0A0A',
                  border: '1px solid #2A2A2A',
                }}
                onFocus={e => (e.target.style.borderColor = '#00BFFF')}
                onBlur={e => (e.target.style.borderColor = '#2A2A2A')}
                placeholder="••••••••"
                autoComplete="current-password"
              />
            </div>

            <AnimatePresence>
              {error && (
                <motion.p
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="text-xs font-dm text-center"
                  style={{ color: '#FF4444' }}
                >
                  {error}
                </motion.p>
              )}
            </AnimatePresence>

            <motion.button
              type="submit"
              disabled={loading}
              whileTap={{ scale: 0.97 }}
              className="w-full py-4 rounded-xl font-bebas text-xl tracking-widest text-white mt-2 relative overflow-hidden"
              style={{
                background: 'linear-gradient(135deg, #00BFFF, #0080FF)',
                boxShadow: '0 0 20px rgba(0,191,255,0.3)',
                fontFamily: "'Bebas Neue', sans-serif",
              }}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" stroke="rgba(255,255,255,0.3)" strokeWidth="3" />
                    <path d="M12 2a10 10 0 0 1 10 10" stroke="white" strokeWidth="3" strokeLinecap="round" />
                  </svg>
                  ENTRANDO...
                </span>
              ) : (
                'ENTRAR'
              )}
            </motion.button>
          </form>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.3 }}
          transition={{ delay: 1 }}
          className="mt-8 text-xs font-dm text-center"
          style={{ color: '#888888' }}
        >
          Acesso restrito
        </motion.p>
      </motion.div>
    </div>
  );
}
